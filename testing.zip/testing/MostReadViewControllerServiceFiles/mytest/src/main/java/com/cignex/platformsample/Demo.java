package com.cignex.platformsample;

/**
 * This class does nothing except dump some output to <i>system.out</i>.
 * This is a sample taken from Maven Alfresco SDK
 * 
 * @author Derek Hulley
 */
public class Demo
{
	public void init()
	{
		System.out.println("Platform JAR Module class has been loaded");
	}
}
