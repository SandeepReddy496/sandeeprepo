package com.cignex.platformsample;

import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.node.NodeServicePolicies;
import org.alfresco.repo.policy.Behaviour;
import org.alfresco.repo.policy.JavaBehaviour;
import org.alfresco.repo.policy.PolicyComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;

public class UserCreationEventHandler 
{
	private static Logger logger = Logger.getLogger(UserCreationEventHandler.class);

    private PolicyComponent eventManager;
    private ServiceRegistry serviceRegistry;

    public void setServiceRegistry(ServiceRegistry serviceRegistry) {
        this.serviceRegistry = serviceRegistry;
    }

    public void setPolicyComponent(PolicyComponent policyComponent) {
        this.eventManager = policyComponent;
    }
    
    public void registerEventHandlers() 
    {
        eventManager.bindClassBehaviour(
                NodeServicePolicies.OnCreateNodePolicy.QNAME,
                ContentModel.TYPE_PERSON,
                new JavaBehaviour(this, "onUserAdd",
                        Behaviour.NotificationFrequency.TRANSACTION_COMMIT));
        
        eventManager.bindClassBehaviour(
                NodeServicePolicies.OnUpdateNodePolicy.QNAME,
                ContentModel.TYPE_PERSON,
                new JavaBehaviour(this, "onUserUpdate",
                        Behaviour.NotificationFrequency.TRANSACTION_COMMIT));
    }
    public void onUserUpdate(NodeRef nodeRef) 
    {
    	NodeService nodeService=serviceRegistry.getNodeService();
    	AuthorityService authorityService=serviceRegistry.getAuthorityService();
    	String sbu=(String)nodeService.getProperty(nodeRef, QName.createQName("http://www.edelweissCustom.com/model/content/1.0", "sbu"));
    	String edelCountry=(String)nodeService.getProperty(nodeRef, QName.createQName("http://www.edelweissCustom.com/model/content/1.0", "edelCountry"));
        String userName=(String)nodeService.getProperty(nodeRef, ContentModel.PROP_USERNAME);
        Boolean userAlreadyInSBU=false;
        String sbuGroup;
        
        String curentUser = AuthenticationUtil.getFullyAuthenticatedUser();
        try 
        {
            //run code as system user.
            AuthenticationUtil.setRunAsUserSystem();
            
            logger.debug("Enter onUserUpdate for user:::"+userName);
        	
        	if(null!=sbu && !"".equals(sbu))
            {
        		sbu="SBU_"+sbu;
            	if(null!=edelCountry && !"".equals(edelCountry))
                {
            		sbu=sbu+"_"+edelCountry;
                }
            	
            	if (authorityService.authorityExists(authorityService.getName(AuthorityType.GROUP, sbu))) 
                {
                	sbuGroup = authorityService.getName(AuthorityType.GROUP, sbu);
                } 
                else 
                {
                	 sbuGroup = authorityService.createAuthority(AuthorityType.GROUP, sbu);
                }
                
                Set<String> existingGroups=authorityService.getAuthoritiesForUser(userName);
               
                for(String grp : existingGroups)
                {
                	if(!"GROUP_EVERYONE".equalsIgnoreCase(grp) && !sbuGroup.equalsIgnoreCase(grp) && !grp.contains("site_") && !"ROLE_ADMINISTRATOR".equalsIgnoreCase(grp)
                			 && !"ALFRESCO_ADMINISTRATORS".equalsIgnoreCase(grp)  && !"GROUP_ALFRESCO_ADMINISTRATORS".equalsIgnoreCase(grp))
                	{
                		//if(!authorityService.getContainingAuthorities(AuthorityType.GROUP, userName, true).contains(grp))
                		{
                			if(!authorityService.getContainingAuthorities(AuthorityType.GROUP, sbuGroup, true).contains(grp))
                    		{
                				authorityService.addAuthority(grp,sbuGroup);
                    		}
                		}
                		authorityService.removeAuthority(grp, userName);
                	}
                	else
                	{
                		if(sbuGroup.equalsIgnoreCase(grp))
                		{
                			userAlreadyInSBU=true;
                		}
                	}
                }
                
                if(!userAlreadyInSBU)
                {
                	authorityService.addAuthority(sbuGroup,userName);
                }
            }
        	
        	logger.debug("userName:::"+userName+"    sbu::::"+sbu + ".....edelCountry........"+edelCountry);
        	logger.debug("Exit onUserUpdate");
            
        }
        catch (Exception e) 
        {
	        logger.debug("Error while executing script: " + e.getMessage());
	        System.out.println("Error::::" + e.getMessage());
        }
        
        AuthenticationUtil.setRunAsUser(curentUser);
    }
    public void onUserAdd(ChildAssociationRef childAssocRef) 
    {	
    	AuthorityService authorityService=serviceRegistry.getAuthorityService();
    	NodeService nodeService=serviceRegistry.getNodeService();
    	
    	// get the parent node
        //NodeRef parentRef = childAssocRef.getParentRef();
        
        NodeRef userNodeRef = childAssocRef.getChildRef();
        
        //String mobile=(String)nodeService.getProperty(userNodeRef, ContentModel.PROP_MOBILE);
        String sbu=(String)nodeService.getProperty(userNodeRef, QName.createQName("http://www.edelweissCustom.com/model/content/1.0", "sbu"));
        String edelCountry=(String)nodeService.getProperty(userNodeRef, QName.createQName("http://www.edelweissCustom.com/model/content/1.0", "edelCountry"));
        String userName=(String)nodeService.getProperty(userNodeRef, ContentModel.PROP_USERNAME);
        logger.debug("Enter onUserAdd for user:::"+userName);
        
        if(null!=sbu && !"".equals(sbu))
        {
        	sbu="SBU_"+sbu;
        	if(null!=edelCountry && !"".equals(edelCountry))
            {
        		sbu=sbu+"_"+edelCountry;
            }
        	String sbuGroup;
            
            if (authorityService.authorityExists(authorityService.getName(AuthorityType.GROUP, sbu))) 
            {
            	sbuGroup = authorityService.getName(AuthorityType.GROUP, sbu);
            } 
            else 
            {
            	 sbuGroup = authorityService.createAuthority(AuthorityType.GROUP, sbu);
            }
            
            Set<String> existingGroups=authorityService.getAuthoritiesForUser(userName);
            for(String grp : existingGroups)
            {
            	if(!"GROUP_EVERYONE".equalsIgnoreCase(grp))
            	{
            		authorityService.removeAuthority(grp, userName);
            		if(!authorityService.getContainingAuthorities(AuthorityType.GROUP, sbuGroup, true).contains(grp))
            		{
            			authorityService.addAuthority(grp,sbuGroup);
            		}
            		
            	}
            }
            
            authorityService.addAuthority(sbuGroup,userName);
            
            logger.debug("sbuGroup::::"+sbuGroup);
        }
        logger.debug("sbu::::"+sbu);
        logger.debug("Exit onUserAdd");
    }
    
}
