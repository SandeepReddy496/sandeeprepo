package com.cignex.platformsample;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

public class Test 
{
	public static void main(String[] args) 
	{
		try
        {
			DateFormat timestampFormat = new SimpleDateFormat("yyyyMMddHHmmss.SSS'Z'", Locale.UK);
			timestampFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			timestampFormat.parse("20171026084358.404Z");
			
			System.out.println("yooo");
        }
        catch (ParseException e)
        {
            System.out.println("Failed to parse timestamp."+ e);
        }

	}

}
