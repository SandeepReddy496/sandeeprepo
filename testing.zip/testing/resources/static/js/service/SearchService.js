angularApp.service('SearchService',
	function($http, UtilService, siteId) {

		this.getPropertiesOf = function(docType) {
			var details = new Array();
			for (var i = 0; i < docType.length; i++) {
			  var doc = docType[i];
				if (doc.name != null || doc.properties != null
					|| doc.id != null || doc.name != undefined
					|| doc.properties != undefined
					|| doc.id != undefined || doc.name != ''
					|| doc.properties != '' || doc.id != '') {

					details.push({
								"displayName" : doc.name.slice(0,doc.name.lastIndexOf(".")),
									   "name" : doc.name,
										 "by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
													: '',
										"cby" : doc.properties["cm:creator"] ? doc.properties["cm:creator"]
													: '',	
								"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
													: '',
											/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
													: '',*/
								"subCategory" : doc.properties["etl:ProductsAndMarketing"] ? doc.properties["etl:ProductsAndMarketing"]
											  : ''|| doc.properties["etl:PerformActuarialAnalysis"] ? doc.properties["etl:PerformActuarialAnalysis"]
											  : ''|| doc.properties["etl:SalesProducts"] ? doc.properties["etl:SalesProducts"]
											  : ''|| doc.properties["etl:OperationsAndServices"] ? doc.properties["etl:OperationsAndServices"]
											  : ''|| doc.properties["etl:ManageInvestments"] ? doc.properties["etl:ManageInvestments"]
											  : ''|| doc.properties["etl:AdminAndFacilities"] ? doc.properties["etl:AdminAndFacilities"]
											  : ''|| doc.properties["etl:RiskManagement"] ? doc.properties["etl:RiskManagement"]
											  : ''|| doc.properties["etl:Finance"] ? doc.properties["etl:Finance"]
											  : ''|| doc.properties["etl:HumanResources"] ? doc.properties["etl:HumanResources"]
											  : ''|| doc.properties["etl:InformationTechnology"] ? doc.properties["etl:InformationTechnology"]
											  : ''|| doc.properties["etl:LegalAndCompliance"] ? doc.properties["etl:LegalAndCompliance"]
											  : '',
											/*"subCategorypa" : doc.properties["etl:PerformActuarialAnalysis"] ? doc.properties["etl:PerformActuarialAnalysis"]
													: '',
											"subCategorysp" : doc.properties["etl:SalesProducts"] ? doc.properties["etl:SalesProducts"]
													: '',*/
											/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
													: '',*/
											"id" : doc.id
										});
							}
						}
						return details;
					}

					this.createSearchTerm = function(term) {
						var searchTerm
						searchTerm = '\"' + term + '\" OR cm:name:\"' + term
								+ '\" OR cm:title:\"' + term
								+ '\" OR cm:description:\"' + term
								+ '\" OR cm:content:\"' + term

						var splitTerm = term.split(/\s+/);
						for (var j = 0; j < splitTerm.length; j++) {
							searchTerm = searchTerm + ' OR \"' + splitTerm[j]
									+ '\" OR cm:name:\"' + splitTerm[j]
									+ '\" OR cm:title:\"' + splitTerm[j]
									+ '\" OR cm:description:\"' + splitTerm[j]
									+ '\" OR cm:content:\"' + splitTerm[j]
									+ '\"';
						}
						return searchTerm;
					}

					this.searchDocuments = function(term, callback) {

						// generating the search term and passing this term in
						// the search API
						term = this.createSearchTerm(term);

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/search/versions/1/search";
						var body = {
							"query" : {
								"query" : "SITE:'" + siteId + "' AND (" + term
										+ ")",
								"language" : "afts"
							},
							"paging" : {
								"maxItems" : 100,
								"skipCount" : 0
							},
							"include" : [ "properties" ],
							"filterQueries" : [ {
								"query" : "TYPE:'cm:content'"
							}, {
								"query" : "-cm:creator:system"
							}, {
								"query" : "-TYPE:'fm:post'"
							} ],
							'defaults' : {
								'textAttributes' : [ 'cm:content', 'cm:name',
										'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
							}
						};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {

							if (response.status === 200) {
								var entries = response.data.list.entries;
								callback(entries);
							} else {
								callback("error");
							}

						}, function errorCallback(response) {
							console.log(response);
							callback("error");
						});

					}
				})