'use strict';

var SearchController = angularApp.controller('SearchController',
				function SearchController($scope, $state, $stateParams,SearchService, UtilService) {

					$scope.alfrescoContext = UtilService.alfrescoContextRoot();
					$scope.token = sessionStorage.getItem('token');

					// set initial index
					// Using variable to control the display
					// ng-show="" in HTML
					/*$scope.loadIndexPresentation = 4;
					$scope.loadIndexVideo = 4;
					$scope.loadIndexDocument = 4;*/
					$scope.loadIndexDocument = 4;

					// function to increase visible items
					$scope.ViewMore = function(item) {
						// don't increment if at the end of the list
						/*if (item === 'presentation') {
							if ($scope.loadIndexPresentation < $scope.presentationCount) {
								$scope.loadIndexPresentation += 4;
								if ($scope.loadIndexPresentation >= $scope.presentationCount) {
									$("#pstViewButton").addClass(
											"disable-view-more-button");
								}
							}
						} else if (item === 'video') {
							if ($scope.loadIndexVideo < $scope.videoCount) {
								$scope.loadIndexVideo += 4;
								if ($scope.loadIndexVideo >= $scope.videoCount) {
									$("#vidViewButton").addClass(
											"disable-view-more-button");
								}
							}
						} else if (item === 'document') {
							if ($scope.loadIndexDocument < $scope.documentCount) {
								$scope.loadIndexDocument += 4;
								if ($scope.loadIndexDocument >= $scope.documentCount) {
									$("#docViewButton").addClass(
											"disable-view-more-button");
								}
							}
						}*/
						
						if (item === 'document') {
							if ($scope.loadIndexDocument < $scope.documentCount) {
								$scope.loadIndexDocument += 4;
								if ($scope.loadIndexDocument >= $scope.documentCount) {
									$("#pstViewButton").addClass("disable-view-more-button");
								}
							}
						}
					}

					var setDetailsOfEachItem = function(segregatedByMime) {
						// count set on UI
						/*$scope.presentationCount = segregatedByMime.presentation.length;
						$scope.videoCount = segregatedByMime.video.length;
						$scope.documentCount = segregatedByMime.document.length;*/
						$scope.documentCount = segregatedByMime.document.length;

						// if count of items is less
						// than 4 then view more
						// button must grey out
						/*if ($scope.presentationCount <= 4) {
							$("#pstViewButton").addClass(
									"disable-view-more-button");
						}
						if ($scope.videoCount <= 4) {
							$("#vidViewButton").addClass(
									"disable-view-more-button");
						}
						if ($scope.documentCount <= 4) {
							$("#docViewButton").addClass(
									"disable-view-more-button");
						}*/
						
						if ($scope.documentCount <= 4) {
							$("#pstViewButton").addClass("disable-view-more-button");
						}

						// getting the properties in an array by mime type
						// setting segregated data array on front end
						/*$scope.presentationDetails = SearchService
								.getPropertiesOf(segregatedByMime.presentation);
						$scope.videoDetails = SearchService
								.getPropertiesOf(segregatedByMime.video);
						$scope.documentDetails = SearchService
								.getPropertiesOf(segregatedByMime.document);*/
				$scope.documentDetails = SearchService.getPropertiesOf(segregatedByMime.document);
					}

					var segregateDataByMimeType = function(listOfItems) {
						var segregatedByMime = new Array();
						/*var presentation = new Array();
						var video = new Array();
						var document = new Array();*/
						var document = new Array();

						for (var i = 0; i < listOfItems.length; i++) {
							var data = listOfItems[i].entry;
							if (data.content != undefined) {
								var mimeType = data.content.mimeType;
								// ppt
								/*if (mimeType === 'application/vnd.ms-powerpoint - ppt'
										|| mimeType === 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
										|| mimeType === 'application/vnd.ms-powerpoint.template.macroenabled.12'
										|| mimeType === 'application/vnd.openxmlformats-officedocument.presentationml.template'
										|| mimeType === 'application/vnd.ms-powerpoint.slideshow.macroenabled.12'
										|| mimeType === 'application/vnd.openxmlformats-officedocument.presentationml.slideshow'
										|| mimeType === 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
										|| mimeType === 'application/vnd.ms-powerpoint.presentation.macroenabled.12'
										|| mimeType === 'application/vnd.ms-powerpoint.addin.macroenabled.12'
										|| mimeType === 'application/vnd.ms-powerpoint.slideshow.macroenabled.12 '
										|| mimeType === 'application/vnd.openxmlformats-officedocument.presentationml.slide'
										|| mimeType === 'application/vnd.ms-powerpoint.slide.macroenabled.12') {
									presentation.push(data);
								}
								// videos
								else if (mimeType === 'video/ogg'
										|| mimeType === 'video/ogg'
										|| mimeType === 'image/gif'
										|| mimeType === 'video/x-msvideo'
										|| mimeType === 'video/quicktime'
										|| mimeType === 'video/x-sgi-movie'
										|| mimeType === 'video/x-ms-wmv'
										|| mimeType === 'video/x-ms-asf'
										|| mimeType === 'audio/mp4'
										|| mimeType === 'video/mp4'
										|| mimeType === 'video/x-m4v'
										|| mimeType === 'video/mpeg'
										|| mimeType === 'video/mp2t'
										|| mimeType === 'video/mpeg'
										|| mimeType === 'video/mpeg2'
										|| mimeType === 'video/mpeg'
										|| mimeType === 'video/3gpp'
										|| mimeType === 'video/3gpp2'
										|| mimeType === 'video/x-flv'
										|| mimeType === 'video/webm') {
									video.push(data);
								}
								// documents
								else {
									document.push(data);
								}*/
								
								if (mimeType != ''){
									
									document.push(data);
								}
							}
						}
						segregatedByMime.push({
							/*"presentation" : presentation,
							"video" : video,*/
							"document" : document
						});
						return segregatedByMime;
					}

					var init = function() {
						var term = $stateParams.term;

						if (term != '' && term != undefined && term != null) {
							SearchService.searchDocuments(term,function(response) {
												if (response != 'error') {
													// seggregating all the
													// response data by mime
													// type
													var segregatedByMime = segregateDataByMimeType(response)[0];
													// setting details of all
													// the documents on frontend
													$scope.allItemsCount = response.length;
													$scope.searchTerm = term;
													setDetailsOfEachItem(segregatedByMime);
												} else {
													console.log('error');
												}
											});
						} else {
							$state.go('homeEtlife');
						}
					}

					angular.element(document).ready(function() {
										console.log("**********SearchController*******");
										$(this).scrollTop(0);
										if (sessionStorage.getItem('token')) {
											init();
										} else {
											sessionStorage.setItem('redirectUrl', $location.absUrl());
											console.log("Search Unauthenticated");
											$state.go('login');
										}
									});
				})