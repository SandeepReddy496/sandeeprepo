'use strict';

var FeedbackReportController = angularApp.controller(
		'FeedbackReportController', function FeedbackReportController($scope,
				$http, $location, $state, FeedbackReportService, UtilService) {

			$scope.isAdmin = false;

			$scope.generateReport = function() {
				console.log("GEneetate Report");
				console.log("From Date: ", $scope.fromDate);
				console.log("To Date: ", $scope.toDate);
			}

			var checkIsAdmin = function(username) {
				FeedbackReportService.checkAdmin(username, function(response) {
					if (response == true) {
						$scope.isAdmin = response;
					} else if (response == false) {
						$scope.isAdmin = false;
					}
				});
			}

			var init = function() {
				$scope.username = sessionStorage.getItem('userId');
				checkIsAdmin($scope.username);
			};

			angular.element(document).ready(function() {
				console.log("**********FeedbackReportController*******");
//				$(this).scrollTop(0);
//				if (sessionStorage.getItem('token')) {
//					init();
//				} else {
//					sessionStorage.setItem('redirectUrl', $location.absUrl());
//					$state.go('login');
//				}
			});
		})