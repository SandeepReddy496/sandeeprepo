'use strict';

var IndexController = angularApp
		.controller(
				'IndexController',
				function IndexController($scope, $stateParams, $rootScope,
						$state, $http, $location, $window, UserDataService,
						UtilService, ControllerService, siteId,
						CommonDataService) {

					$scope.onLogoutClick = function() {
						var method = 'delete';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/authentication/versions/1/tickets/-me-"
						var headers = {
							authorization : "Basic "+ btoa(sessionStorage.getItem('token'))
						}
						var body = {};

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
						.then(function successCallback(response) {
							console.log("Logged out Successfully with response  : ", response);
							//$http.get(UtilService.contextRoot() + '/logout', {})
							//var data=response.data;
							//console.log("Logged out Successfully ", response.status);
							$rootScope.authenticated = false;
							$location.path("/login");
							
						}, function errorCallback(response) {
							console.log("response  : ", response);
						});
						/*$http.get(UtilService.contextRoot() + '/login', {})
						.success(function () {
							$rootScope.authenticated = false;
								$location.path("/login");
						}).error(function (data) {
							console.log("Logout failed")
							$rootScope.authenticated = false;
							$location.path("/login");
							});*/
	
					}
					
					// ############### MostRead start

					/*$scope.mostRead = function() {

						alert("Hi, I am in MostRead with IndexController");
						var nodeId = $stateParams.id;
						// var commentId = event.target.id;

						var method = 'GET';
						// http://localhost:8080/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites=bsg&limit=1000
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites="
								+ siteId + "&limit=1000";

						var body = {};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							console.log(response);
							if (response.status === 204) {
								console.log('Most Viewed Docs', response);
							} else {
								console.log('status != 200');
							}
						}, function errorCallback(response) {
							console.log('error');
						});
					}*/

					// ############### MostRead End


					$scope.onFeedbackSubmitCommentClick = function() {
						if (sessionStorage.getItem('token')) {
							var text = $scope.feedbackText;
							var feedbackType = $scope.feedbackDropdownSelectedOption.name;
							if (text != null || text != undefined || text != ''
									|| text != "") {
								var urlOnPage = $location;
								var userId = sessionStorage.getItem('userId');
								var method = 'post';
								var url = UtilService.contextRoot()
										+ "/api/feedback";
								text = text.trim();
								var body = {
									"username" : String(userId),
									"url" : String(urlOnPage.$$absUrl),
									"feedbackText" : String(text),
									"feedbackType" : String(feedbackType)
								};

								var headers = {
									'Content-Type' : 'application/json'
								}

								$http({
									method : method,
									url : url,
									headers : headers,
									data : body
								}).then(function successCallback(response) {
									console.log(response);
									if (response.status === 200) {
										console.log('status 200');
									} else {
										console.log('status != 200');
									}
								}, function errorCallback(response) {
									console.log('error', response);
								});
							}
							$scope.feedbackText = '';
							$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
							document.getElementById("#myModal");
						} else {
							state.go('login');
						}
					}

					$scope.onMainSearchClick = function() {
						var text = $scope.mainSearchText;
						$scope.selectedMenuItem = '';
						$state.go('search', {
							term : text
						});
					}


					$scope.onAboutUsClick = function() {

					}

					$scope.onSubscribeClick = function() {

					}

					var initilizeFeedbackDropdown = function() {
						$scope.feedbackDropdownOptions = [ {
							name : "I like something",
							id : 1
						}, {
							name : "I dislike something",
							id : 2
						}, {
							name : "I have a suggestion",
							id : 3
						} ];
						$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
					};
					
					/*var closeSelf =function(){
					    // do something

					    if(condition satisfied){
					       alert("conditions satisfied, submiting the form.");
					       document.forms['certform'].submit();
					       window.close();
					    }else{
					       alert("conditions not satisfied, returning to form");    
					    }
					}*/

					$scope.initApp = function() {
						initilizeFeedbackDropdown();

					};

					angular.element(document).ready(
									function() {
										console.log("**********IndexController*******");
										if ($rootScope.authenticated) {
											sessionStorage.setItem('redirectUrl', $location.absUrl());
											$scope.showSessionExpired();
											$scope.initApp();
										} else {
											ControllerService.checkIfAlreadyAuthenticated(function() {
														//$scope.selectedMenuItem = 'Products';
														if ($rootScope.authenticated) {
															sessionStorage.setItem('redirectUrl',$location.absUrl());
															$scope.initApp();
														} else {
															sessionStorage.setItem('redirectUrl',$location.absUrl());
															$scope.initApp();
															$state.go('login');
														}
													});
										}
									});

				});