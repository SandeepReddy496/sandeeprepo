'use strict';

var angularApp = angular.module('angularApp', [ 'ui.router', 'ngResource',
		'ngRoute', 'angularApp.directives', 'angularApp.services',
		// 'angularApp.ViewService', 'angularApp.SearchService',
		'angulartics', 'angulartics.piwik' ]);

//angularApp.constant("siteId", "corporate-controller-bpri")
angularApp.constant("siteId", "etlife")

angularApp.config(function($stateProvider, $routeProvider, $httpProvider) {

	$stateProvider.state('login', {
		url : '/login',
		templateUrl : 'html/loginEtlife.html',
		controller : 'LoginController'

	})
	
	.state('homeEtlife', {
		url : '/homeEtlife',
		templateUrl : 'html/homeEtlife.html',
		controller : 'HomeController'

	})
	
	.state('search', {
		url : '/search?:term',
		templateUrl : 'html/search.html',
		controller : 'SearchController'
	})

	.state('filter-search', {
		url : '/filter-search?:category?:term',
		templateUrl : 'html/filter-search.html',
		controller : 'FilterSearchController'
	})
	
	/*.state('filter-searchpa', {
		url : '/filter-searchpa?:category?:term',
		templateUrl : 'html/filter-searchpa.html',
		controller : 'FilterSearchController'

	})
	.state('filter-searchsp', {
		url : '/filter-searchsp?:salesProducts?:term',
		templateUrl : 'html/filter-searchsp.html',
		controller : 'FilterSearchController'

	})*/
	.state('mostRead', {
		url : '/mostRead',
		templateUrl : 'html/mostRead.html',
		controller : 'mostReadController'
	})
	

	.state('view', {
		url : '/view?:id?:fileName?:author',
		templateUrl : 'html/view.html',
		controller : 'ViewController'
	})
	

	.state('feedback-report', {
		url : '/admin/feedback-report',
		templateUrl : 'html/admin/feedback-report.html',
		controller : 'FeedbackReportController'
	})

	.state('about', {
		url : '/about',
		templateUrl : 'html/about.html',
		controller : 'AboutController'

	})

	$httpProvider.defaults.headers.common['Authorization'] = 'Basic '
			+ btoa(sessionStorage.getItem('token'));
});
