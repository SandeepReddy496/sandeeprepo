 // JavaScript Document
$(document).ready(function() {
	 
$(window).scroll(function(){
	if($(window).scrollTop()>34){
		$('header').addClass('smallBox');
	}
	else{
		$('header').removeClass('smallBox');
	}
});	
	 
$('input').data('holder',$('input').attr('placeholder'));

$('input').focusin(function(){
    $(this).attr('placeholder','');
});
$('input').focusout(function(){
    $(this).attr('placeholder',$(this).data('holder'));
});
//
$('.menuBox').click(function(){
//	$('body').toggleClass('push_right');
	$('.menuProlist').slideToggle('100');
	$('.menuBox').toggleClass('menuSect');
	
	function checkWidth() {
        var windowSize = $(window).width();
    if (windowSize < 480) {
    $('.menuProlist ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:1,
		moveSlides:1,
		minSlides:1,
		slideWidth: 230,
		slideMargin: 20 
	});
        }
        else if (windowSize < 768) {
    $('.menuProlist ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:2,
		moveSlides:1,
		minSlides:1,
		slideWidth: 270,
		slideMargin: 20 
	});
        }
        else if (windowSize < 960) {
           $('.menuProlist ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:3,
		moveSlides:1,
		minSlides:1,
		slideWidth: 230,
		slideMargin: 20 
	});
        }
		else if (windowSize < 1020) {
           $('.menuProlist ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:3,
		moveSlides:1,
		minSlides:1,
		slideWidth: 230,
		slideMargin: 20 
	});
        }
		else if (windowSize < 1100) {
           $('.menuProlist ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:4,
		moveSlides:1,
		minSlides:1,
		slideWidth: 230,
		slideMargin: 20 
	});
        }
        else {
	$('.menuProlist ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:4,
		moveSlides:1,
		minSlides:1,
		slideWidth: 270,
		slideMargin: 20 
	});
        }
    }
 // Execute on load
    checkWidth();
    // Bind event listener
    $(window).resize(checkWidth);	
	
});

 

//
	$('.hMenu').click(function(){
		$('.topRIght').toggleClass('right300');
		$('body').toggleClass('noscroll');
		$('.hMenu').toggleClass('menuSect');
		return false;
	});



$('.slider').bxSlider({
		auto:false,
		pager:false,
		pause:4000,
      infiniteLoop: false,
      hideControlOnEnd: true,
	  autoStart:true,
	  stopAuto: false,
	  
		 
	});
	
	/*$('.menuProlist2 ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:4,
		moveSlides:1,
		minSlides:1,
		slideWidth: 270,
		slideMargin: 20 
	});*/
	 
	 $('.tabSlider').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:5,
		moveSlides:1,
		minSlides:1,
		slideWidth: 100,
		slideMargin: 20 
	});
	
	
	function checkWidth2() {
        var windowSize2 = $(window).width();

    if (windowSize2 < 480) {
    $('.menuProlist2 ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:1,
		moveSlides:1,
		minSlides:1,
		slideWidth: 230,
		slideMargin: 20 
	});
        }
        else if (windowSize2 < 768) {
    $('.menuProlist2 ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:2,
		moveSlides:1,
		minSlides:1,
		slideWidth: 270,
		slideMargin: 20 
	});
        }
        else if (windowSize2 < 960) {
           $('.menuProlist2 ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:3,
		moveSlides:1,
		minSlides:1,
		slideWidth: 230,
		slideMargin: 20 
	});
        }
		else if (windowSize2 < 1020) {
           $('.menuProlist2 ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:3,
		moveSlides:1,
		minSlides:1,
		slideWidth: 230,
		slideMargin: 20 
	});
        }
		else if (windowSize2 < 1100) {
           $('.menuProlist2 ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:4,
		moveSlides:1,
		minSlides:1,
		slideWidth: 230,
		slideMargin: 20 
	});
        }
        else {
	$('.menuProlist2 ul').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:4,
		moveSlides:1,
		minSlides:1,
		slideWidth: 270,
		slideMargin: 20 
	});
        }
    }
 // Execute on load
    checkWidth2();
    // Bind event listener
    $(window).resize(checkWidth2);	

$(document).ready(function () {

    var n = $(".slider-slide-wrap").length,
        width = 194,
        newwidth = width * n;

    $('.slide-wrap').css({
        'width': newwidth
    });

    $(".slider-slide-wrap").each(function (i) {
        var thiswid = 194;
        $(this).css({
            'left': thiswid * i
        });

    });
    /*on scroll move the indicator 'shown' class to the
    most visible slide on viewport
    */
    $('.slider-wrap').scroll(function () {
        var scrollLeft = $(this).scrollLeft();
        $(".slider-slide-wrap").each(function (i) {
            var posLeft = $(this).position().left
            var w = $(this).width();
           
            if (scrollLeft >= posLeft && scrollLeft < posLeft + w) {
              $(this).addClass('shown').siblings().removeClass('shown');
            }
        });
    });
    /* on left button click scroll to the previous sibling of the current visible slide */
    $('#slider-left').click(function () {
        var $prev = $('.slide-wrap .shown').prev();

        if ($prev.length) {
            $('.slider-wrap').animate({
                scrollLeft: $prev.position().left
            }, 'slow');
        }
    });
    /* on right button click scroll to the next sibling of the current visible slide */
    $('#slider-right').click(function () {
        var $next = $('.slide-wrap .shown').next();

        if ($next.length) {
            $('.slider-wrap').animate({
                scrollLeft: $next.position().left
            }, 'slow');
        }
    });
});


$('.tabSlider').bxSlider({
		auto:false,
		pager:false,
		infiniteLoop: false,
		hideControlOnEnd: true,
		maxSlides:5,
		moveSlides:1,
		minSlides:1,
		slideWidth: 100,
		slideMargin: 20 
	});
	
	$(".tabsMain li").click(function(e){
		e.stopPropagation();
		$(".tabsMain li").removeClass('active');
		$(this).addClass('active');
		console.log("called");
		var dataclick = $(this).attr("data-click");
		$(".listBox").hide();
		$("#"+dataclick).show();
	});

});


 