package com.edelweiss.bpri.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edelweiss.bpri.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, String> {

	public User findByUserNameIgnoreCase(String userName);

}
