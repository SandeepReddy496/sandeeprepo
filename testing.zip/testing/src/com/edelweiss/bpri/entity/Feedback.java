package com.edelweiss.bpri.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;

@Entity
@Table(name = "BPRI", schema = "public")
public class Feedback implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "feedback_sequence")
	@SequenceGenerator(sequenceName = "feedback_sequence", allocationSize = 1, name = "feedback_sequence", initialValue = 1)
	private Long id;

	@Column(name = "CREATED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	private Date createdDate;

	@Column(name = "USERNAME", nullable = false)
	private String username;

	@Column(name = "URL")
	private String url;

	@Column(name = "FEEDBACK_TEXT")
	private String feedbackText;

	@Column(name = "Feedback_Type")
	private String feedbackType;

	public Feedback(Date createdDate, String username, String url, String feedbackText, String feedbackType) {
		super();
		this.createdDate = createdDate;
		this.username = username;
		this.url = url;
		this.feedbackText = feedbackText;
		this.feedbackType = feedbackType;
	}

	public Feedback() {
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFeedbackText() {
		return feedbackText;
	}

	public void setFeedbackText(String feedbackText) {
		this.feedbackText = feedbackText;
	}

	public String getFeedbackType() {
		return feedbackType;
	}

	public void setFeedbackType(String feedbackType) {
		this.feedbackType = feedbackType;
	}
}
