package com.edelweiss.bpri.controller;

import java.io.File;

import java.io.FileNotFoundException;
import javax.servlet.ServletContext;


import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;



import com.edelweiss.bpri.entity.Feedback;
import com.edelweiss.bpri.entity.User;
import com.edelweiss.bpri.mailsender.SendEmail;
//import com.edelweiss.bpri.managers.UploadManager;
//import com.edelweiss.bpri.entity.Upload;
import com.edelweiss.bpri.service.FeedbackService;
import com.edelweiss.bpri.service.UserService;

@RestController
public class ApiController {

	private static final Log LOG = LogFactory.getLog(ApiController.class);
	
	@Autowired
	FeedbackService feedbackService;
	
	/*@Autowired
	private ServletContext servletContext;*/
	
	
	@Autowired
	UserService UserService;
	
	@Autowired
	SendEmail sendMail;
	
	String dmsFileName;

	@RequestMapping(value = "/api", method = RequestMethod.GET)
	public String main() {
		return "Best Practices API Explorer";
	}

	@RequestMapping(value = "/api/feedback", method = RequestMethod.POST)
	public ResponseEntity<Feedback> saveFeedback(@RequestBody Feedback feedback) {
		// return feedbackService.saveFeedback(feedback);
		
		System.out.println("#####: in FeedBack API Controlle: ####r");
		String feedbackType = feedback.getFeedbackType().toString();
		System.out.println("++ FeedBack Type: ++ "+feedbackType);
		String feedbackText = feedback.getFeedbackText().toString();
		System.out.println("++ FeedBack Text: ++ "+feedbackText);
		
		sendMail.sendmail(feedbackType,feedbackText);
		//sendMail.sendmail(feedbackText);
		System.out.println("Mail send Sucessfully");
		
		return new ResponseEntity<Feedback>(feedbackService.saveFeedback(feedback), HttpStatus.OK);
	}
	
	

	@RequestMapping(value = "/api/admin/check", method = RequestMethod.POST)
	public ResponseEntity<Boolean> checkAdmin(@RequestBody User user) {
		String userName = user.getUsername();
		boolean isUserAvailable = false;
		if (UserService.getUser(userName)) {
			isUserAvailable = true;
		}
		return new ResponseEntity<Boolean>(isUserAvailable, HttpStatus.OK);
	}

	@RequestMapping(value = "/api/admin/download/feedback-report/{fromDate}/{toDate}", method = RequestMethod.GET)
	public ResponseEntity<InputStreamResource> generateFeedbackReport(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) throws FileNotFoundException {

		boolean status = feedbackService.generateFeedbackExcel(fromDate, toDate);
		if (status) {
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			headers.add("Content-disposition", "attachment;filename=Feedback.xlsx");

			File file = null;
			file = new File("C:\\Users\\DeepakBatra\\Desktop\\Feedback.xlsx");
			return ResponseEntity.ok().headers(headers).contentLength(file.length())
					.contentType(MediaType
							.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
					.body(feedbackService.downloadReport());
		}
		return null;
	}
	

	
}
