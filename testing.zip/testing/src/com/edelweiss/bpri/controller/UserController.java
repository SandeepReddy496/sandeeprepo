package com.edelweiss.bpri.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

}
