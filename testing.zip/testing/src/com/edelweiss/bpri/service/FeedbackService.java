package com.edelweiss.bpri.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.transaction.Transactional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.edelweiss.bpri.dao.FeedbackRepository;
import com.edelweiss.bpri.entity.Feedback;

@Service
public class FeedbackService {

	@Autowired
	FeedbackRepository feedbackRepository;

	@Transactional
	public Feedback saveFeedback(Feedback feedback) {
		feedback.setCreatedDate(feedback.getCreatedDate());
		feedback.setFeedbackText(feedback.getFeedbackText());
		feedback.setUrl(feedback.getUrl());
		feedback.setUsername(feedback.getUsername());
		feedback.setCreatedDate(new Date());
		feedback.setFeedbackType(feedback.getFeedbackType());
		feedbackRepository.save(feedback);
		return feedback;
	}

	public boolean generateExcelOnServer(List<Feedback> list, String name) {

		boolean returnStatus = true;
		/** Apache POI Initialization */
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet(name);
		XSSFRow row;
		Map<String, Object[]> reportData = new TreeMap<String, Object[]>();
		String[] columnNames = { "Created Date", "User", "Type Of Feedback", "Feedback", "Feedback URL" };
		String[] fieldNames = { "createdDate", "username", "feedbackType", "feedbackText", "url" };
		System.out.println(fieldNames.length);

		reportData.put("1", columnNames);
		int rowNum = 2;

		for (int i = 0; i < list.size(); i++) {
			Feedback dto = (Feedback) list.get(i);
			Object[] objArray = new Object[fieldNames.length];
			Class<? extends Object> class1 = dto.getClass();
			int objNumber = 0;
			for (String fieldName : fieldNames) {
				System.out.println(fieldName);
				try {
					Field field = class1.getDeclaredField(fieldName);
					field.setAccessible(true);
					if (field.get(dto) == null) {
						objArray[objNumber] = "";
					} else {
						String value = field.get(dto).toString();
						objArray[objNumber] = value;
					}
					objNumber++;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
					returnStatus = false;
				} catch (IllegalAccessException e) {
					e.printStackTrace();
					returnStatus = false;
				} catch (NoSuchFieldException e) {
					e.printStackTrace();
					returnStatus = false;
				} catch (SecurityException e) {
					e.printStackTrace();
					returnStatus = false;
				} catch (Exception e) {
					e.printStackTrace();
					returnStatus = false;
				}
			}
			reportData.put(Integer.toString(rowNum), objArray);
			rowNum++;
			/** Iterate over data and write to sheet */

			Set<String> keyid = reportData.keySet();
			int rowid = 0;
			for (String key : keyid) {
				row = sheet.createRow(rowid++);
				Object[] objectArr = reportData.get(key);
				int cellid = 0;
				for (Object obj : objectArr) {
					Cell cell = row.createCell(cellid++);
					cell.setCellValue((String) obj);
				}
			}
			FileOutputStream out;
			try {
				out = new FileOutputStream(new File("C:\\Users\\DeepakBatra\\Desktop\\" + name + ".xlsx"));
				workbook.write(out);
				out.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				returnStatus = false;
			} catch (IOException e) {
				e.printStackTrace();
				returnStatus = false;
			}
			System.out.println(name + ".xlsx written successfully");
		}
		return returnStatus;
	}

	public boolean generateFeedbackExcel(String fromDate, String toDate) {

		fromDate = fromDate.replace("T", " ").replaceAll("Z", "").replaceAll("\"", "").replaceAll(".000", "");
		toDate = toDate.replace("T", " ").replaceAll("Z", "").replaceAll("\"", "");

		fromDate = fromDate.replace("\"","");
		toDate = toDate.replace("\"","");
		
		System.out.println("FromDate: " + fromDate);
		System.out.println("toDate: " + toDate);
		
		
		String fromDateString = fromDate;
		DateFormat df1 = new SimpleDateFormat("MM/dd/yyyy"); 
		Date fDate = null;
		try {
			fDate = df1.parse(fromDateString);
		    String newDateString = df1.format(fDate);
		    System.out.println(newDateString);
		} catch (ParseException e) {
		    e.printStackTrace();
		}
		
		String toDateString = toDate;
		DateFormat df2 = new SimpleDateFormat("MM/dd/yyyy"); 
		Date tDate = null;
		try {
			tDate = df2.parse(toDateString);
		    String newDateString = df2.format(tDate);
		    System.out.println(newDateString);
		} catch (ParseException e) {
		    e.printStackTrace();
		}
		
		List<Feedback> feedbacks = feedbackRepository.findFromDateToDate(fDate, tDate);
		// List<Feedback> feedbacks = feedbackRepository.findFromDateToDate(FromDate,
		// toDate);
		// List<Feedback> feedbacks = feedbackRepository.findFromDateToDate(s);
		String fileName = "Feedback";
		boolean status = true;
		try {
			status = generateExcelOnServer(feedbacks, fileName);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			status = false;
		} catch (SecurityException e) {
			e.printStackTrace();
			status = false;
		}
		return status;
	}

	public InputStreamResource downloadReport() throws FileNotFoundException {
		File file = null;
		file = new File("C:\\Users\\DeepakBatra\\Desktop\\Feedback.xlsx");
		InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
		return resource;
	}

}
