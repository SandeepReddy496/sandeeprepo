## If you are overriding out-of-the-box Alfresco web scripts, put these files here
## in the correct org.alfresco... package.
## If you are defining a new custom web script, add it under
## resources/alfresco/web-extension/site-webscripts/{your domain path}.
##

