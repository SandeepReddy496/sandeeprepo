package com.edelweiss.cms.utils;

import org.alfresco.service.namespace.QName;

public interface EdelweissContentModel {
	
	String EDELWEISS_MODEL_URI = "http://www.edelweiss.com/model/content/1.0";
	QName ASPECT_DOCUMENT_CLASSIFICATION = QName.createQName(EDELWEISS_MODEL_URI, "documentClassification");
	
	QName PROP_CUSTOM_CREATION_DATE = QName.createQName(EDELWEISS_MODEL_URI, "customCreationDate");
	QName PROP_DOC_PREVIEW_COUNT = QName.createQName(EDELWEISS_MODEL_URI, "docPreviewCount");
	QName PROP_DOC_DOWNLOAD_COUNT = QName.createQName(EDELWEISS_MODEL_URI, "docDownloadCount");
	QName PROP_DOC_PRIORITY_TERMS = QName.createQName(EDELWEISS_MODEL_URI, "docPriorityTerms");
	
}
