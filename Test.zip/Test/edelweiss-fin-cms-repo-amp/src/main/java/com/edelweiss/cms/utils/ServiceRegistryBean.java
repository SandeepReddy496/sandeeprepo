package com.edelweiss.cms.utils;

/**
 * Bean use to hold service registry used in migration and article status count
 * manager class
 * 
 * @author faizaan.shaikh
 */
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.search.SearchService;

public class ServiceRegistryBean
{
    private ServiceRegistry serviceRegistry;
    private SearchService searchService;

    /**
     * @return the serviceRegistry
     */
    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;

        AlfrescoServiceRegistry.setServiceRegistry(this.serviceRegistry);

    }

    /**
     * @param searchService the searchService to set
     */
    public void setSearchService(SearchService searchService)
    {
        this.searchService = searchService;
        AlfrescoServiceRegistry.setSearchService(this.searchService);
    }

    /**
     * @return the searchService
     */
    public SearchService getSearchService()
    {
        return searchService;
    }

}
