package com.edelweiss.cms.utils;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.search.SearchService;

/**
 * Singleton service registry used in migration and article status count manager
 * 
 * @author faizaan.shaikh
 * 
 */

public final class AlfrescoServiceRegistry
{
    private static ServiceRegistry serviceRegistry;
    private static SearchService searchService;

    private AlfrescoServiceRegistry()
    {

    }

    public static void setServiceRegistry(final ServiceRegistry serviceRegistry)
    {
        AlfrescoServiceRegistry.serviceRegistry = serviceRegistry;
    }

    public static ServiceRegistry getServiceRegistry()
    {
        return AlfrescoServiceRegistry.serviceRegistry;
    }

    public static void setSearchService(SearchService searchService)
    {
        AlfrescoServiceRegistry.searchService = searchService;
    }

    public static SearchService getSearchService()
    {
        return AlfrescoServiceRegistry.searchService;
    }

}