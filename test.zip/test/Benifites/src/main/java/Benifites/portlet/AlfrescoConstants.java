package Benifites.portlet;

public class AlfrescoConstants {
	
	private AlfrescoConstants() {
		throw new IllegalStateException("Benefits Constant Class");
	}
	
	public static final String REPO_TYPE_SETTINGS = "ATOM";
	public static final String REPO_CLASS="com.liferay.document.library.repository.custom.cmis.internal.CustomCMISAtomPubRepository";
	public static final String SITE_FOLDER = "Sites";
	public static final String DEFAULT_SITE = "swsdp";
	public static final String DOCUMENT_LIBERARY = "documentLibrary";
	
	
	

}
