package Benifites.portlet;

import java.io.Serializable;

import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;

public class BenifitesPojo implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long benifitesAlfId;
	private Folder folder;
	private FileEntry fileEntry;
	private String previewURL;
	public BenifitesPojo(){}
	public BenifitesPojo(long benifitesAlfId, Folder folder, FileEntry fileEntry) {
		super();
		this.benifitesAlfId = benifitesAlfId;
		this.folder = folder;
		this.fileEntry = fileEntry;
	}
	public long getBenifitesAlfId() {
		return benifitesAlfId;
	}
	public void setBenifitesAlfId(long benifitesAlfId) {
		this.benifitesAlfId = benifitesAlfId;
	}
	public Folder getFolder() {
		return folder;
	}
	public void setFolder(Folder folder) {
		this.folder = folder;
	}
	public FileEntry getFileEntry() {
		return fileEntry;
	}
	public void setFileEntry(FileEntry fileEntry) {
		this.fileEntry = fileEntry;
	}
	public String getPreviewURL() {
		return previewURL;
	}
	public void setPreviewURL(String previewURL) {
		this.previewURL = previewURL;
	}
}
