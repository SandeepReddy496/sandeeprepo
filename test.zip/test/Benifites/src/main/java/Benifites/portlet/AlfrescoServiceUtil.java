package Benifites.portlet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.edlewiess.benifites.alfadmin.model.BenifitesAlf;
import com.edlewiess.benifites.alfadmin.service.BenifitesAlfLocalServiceUtil;
import com.edlewiess.portal.benifitesite.model.BenifiteSite;
import com.edlewiess.portal.benifitesite.service.BenifiteSiteLocalServiceUtil;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.document.library.kernel.service.DLAppServiceUtil;
import com.liferay.document.library.kernel.util.DLUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Repository;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.service.RepositoryLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;


public class AlfrescoServiceUtil {

	private static final Log LOG = LogFactoryUtil.getLog(AlfrescoServiceUtil.class);

	private AlfrescoServiceUtil() {
		throw new IllegalStateException("Benefits Alfresco Utility class");
	}

	public static List<BenifitesPojo> getFolders(ThemeDisplay themeDisplay) {
		List<BenifitesPojo> benifitsAlfPojos = new ArrayList<>(0);

		// MAP THE ICON HERE.
		List<Folder> folderToSend = getFoldersFromAlf();

		// INSERT THE MISSING ALFRESCO FOLDERS...
		for (Folder folder : folderToSend) {

			List<BenifitesAlf> benifitesAlfs = BenifitesAlfLocalServiceUtil.findByFolderId(folder.getFolderId());
			if (!benifitesAlfs.isEmpty()) {
				// GET ALL THE FOLDERS FOR MAPPING
				BenifitesAlf benF = benifitesAlfs.get(0);

				FileEntry fileEntry = null;
				String previewUrl = null;
				try {
					fileEntry = benF.getFileEntryId() != 0l ? DLAppServiceUtil.getFileEntry(benF.getFileEntryId())
							: null;
					previewUrl = fileEntry != null
							? DLUtil.getPreviewURL(fileEntry, fileEntry.getFileVersion(), themeDisplay, StringPool.BLANK) : null;
				} catch (PortalException e) {
					LOG.error(e.getMessage());
				}
				BenifitesPojo alfAdminPojo = new BenifitesPojo();
				alfAdminPojo.setFileEntry(fileEntry);
				alfAdminPojo.setPreviewURL(previewUrl);
				alfAdminPojo.setFolder(folder);
				alfAdminPojo.setBenifitesAlfId(benF.getBenifitId());
				benifitsAlfPojos.add(alfAdminPojo);
			} else {
				// INSERT BENIFIT ALF
				BenifitesAlf benAlf = BenifitesAlfLocalServiceUtil
						.createBenifitesAlf(CounterLocalServiceUtil.increment(BenifitesAlf.class.getName()));
				benAlf.setFolderId(folder.getFolderId());
				BenifitesAlfLocalServiceUtil.addBenifitesAlf(benAlf);
			}

		}
		return benifitsAlfPojos;
	}

	public static Repository getAlfRepository() {
		List<Repository> repositories = RepositoryLocalServiceUtil.getRepositories(-1, -1);

		Repository rep = null;
		for (Repository repository : repositories) {			
			if (Validator.isNotNull(repository.getTypeSettings())
					&& repository.getClassName().equals(AlfrescoConstants.REPO_CLASS)
					&& !Validator.isBlank(repository.getTypeSettings())
					&& !repository.getTypeSettings().equals("\'\'")) {
				rep = repository;
				break;
			}
		}
		return rep;
	}

	public static List<Folder> getFoldersFromAlf() {

		List<Folder> folderToSend = new ArrayList<>(0);

		Repository rep = getAlfRepository();
		try {
			
			if (rep != null) {
			
				List<Folder> folderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(), rep.getDlFolderId(), -1,
						-1);
			
				for (int i = 0; i < folderList.size()
						&& folderList.get(i).getName().equals(AlfrescoConstants.SITE_FOLDER); i++) {

					
					List<Folder> subFolderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(),
							folderList.get(i).getFolderId());
									
					// Getting Sitename folder List
					for (int j = 0; j < subFolderList.size()
							&& !subFolderList.get(j).getName().equals(AlfrescoConstants.DEFAULT_SITE); j++) {
						List<Folder> siteFolderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(),
								subFolderList.get(j).getFolderId());

						// Getting DocumentLiberary Folder List
						for (int k = 0; k < siteFolderList.size()
								&& siteFolderList.get(k).getName().equals(AlfrescoConstants.DOCUMENT_LIBERARY); k++) {
							List<Folder> docLibFolderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(),
									siteFolderList.get(k).getFolderId());
							folderToSend.addAll(docLibFolderList);
						}

					}
				}
			}
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
		return folderToSend;
	}

	public static List<Folder> getAllFolderIds(long parentFolderId, long repositoryId) {

		List<Folder> folderIds = new ArrayList<>(0);

		// get all the files from a directory
		List<Folder> folderList = new ArrayList<>(0);
		try {
			folderList = DLAppServiceUtil.getFolders(repositoryId, parentFolderId);
			folderIds.addAll(folderList);
			for (Iterator<Folder> folder = folderList.iterator(); folder.hasNext();) {
				folderIds.addAll(getAllFolderIds((folder.next()).getFolderId(), repositoryId));
			}

		} catch (PortalException e) {
			LOG.error(e.getMessage());
		}

		return folderIds;
	}

	public static List<Folder> getFoldersFromsite() {
		List<Folder> folderToSend = new ArrayList<>(0);

		Repository rep = getAlfRepository();
		try {
			
			if (rep != null) {
				List<Folder> folderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(), rep.getDlFolderId(), -1,
						-1);

				for (Folder folder : folderList) {
					if (folder.getName().equals(AlfrescoConstants.SITE_FOLDER)) {
						List<Folder> subFolderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(),
								folder.getFolderId());
						folderToSend.addAll(subFolderList);

					}
				}
			}
		} catch (NullPointerException | PortalException e) {
			LOG.error(e.getMessage());
		}
		
		return folderToSend;
	}

	public static long getFoldersFromsitebyName(String sitename) {
		Repository rep = getAlfRepository();
		try {
			if (rep != null) {
				List<Folder> folderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(), rep.getDlFolderId(), -1,
						-1);

				for (Folder folder : folderList) {
					if (folder.getName().equals(AlfrescoConstants.SITE_FOLDER)) {
						List<Folder> subFolderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(),
								folder.getFolderId());
						for (Folder folder2 : subFolderList) {
							if (folder2.getName().equalsIgnoreCase(sitename)) {
								return folder2.getFolderId();
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}

		return 0;
	}

	public static List<Folder> getFoldersFromBenifitesite() {

		List<Folder> folderToSend = new ArrayList<>(0);
		Repository rep = getAlfRepository();
		try {
			if (rep != null) {
				Folder folder = DLAppServiceUtil.getFolder(rep.getRepositoryId(), rep.getDlFolderId(),
						AlfrescoConstants.SITE_FOLDER);
				List<BenifiteSite> sitelist = BenifiteSiteLocalServiceUtil.getBenifiteSites(0,
						CounterLocalServiceUtil.getCountersCount());
				for (BenifiteSite lstsite : sitelist) {
					// Getting Sitename folder List

					Folder folderGet = DLAppServiceUtil.getFolder(rep.getRepositoryId(), folder.getFolderId(),
							lstsite.getFoldername());

					/*
					 * List<Folder> siteFolderList =
					 * DLAppServiceUtil.getFolders(rep.getRepositoryId(),
					 * folderGet.getFolderId());
					 */

					Folder folder2 = DLAppServiceUtil.getFolder(rep.getRepositoryId(), folderGet.getFolderId(),
							AlfrescoConstants.DOCUMENT_LIBERARY);

					// Getting DocumentLiberary Folder List
					/* for (Folder folder2 : siteFolderList) { */
					/*
					 * if (folder2.getName().equals(AlfrescoConstants.
					 * DOCUMENT_LIBERARY)) {
					 */
					List<Folder> docLibFolderList = DLAppServiceUtil.getFolders(rep.getRepositoryId(),
							folder2.getFolderId());
					folderToSend.addAll(docLibFolderList);
					/* } */
					/* } */

				}
			}

		} catch (Exception e) {
		}
		return folderToSend;

	}

}
