package Benifites.constants;

/**
 * @author Dattu
 */
public class BenifitesPortletKeys {

	public static final String Benifites = "Benifites";

}