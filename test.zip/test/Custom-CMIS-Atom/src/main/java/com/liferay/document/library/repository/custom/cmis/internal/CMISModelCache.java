/**
 * Copyright (c) 2000-2017 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.liferay.document.library.repository.custom.cmis.internal;

import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.util.AutoResetThreadLocal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Adolfo P??rez
 */
public class CMISModelCache {

	public List<FileEntry> getFileEntries(long folderId) {
		Map<Long, List<FileEntry>> fileEntriesMap = _fileEntriesMaps.get();

		return fileEntriesMap.get(folderId);
	}

	public FileEntry getFileEntry(long fileEntryId) {
		Map<Long, FileEntry> fileEntryMap = _fileEntryMaps.get();

		return fileEntryMap.get(fileEntryId);
	}

	public Folder getFolder(long folderId) {
		Map<Long, Folder> folderMap = _folderMaps.get();

		return folderMap.get(folderId);
	}

	public List<Folder> getFolders(long folderId) {
		Map<Long, List<Folder>> foldersMap = _foldersMap.get();

		return foldersMap.get(folderId);
	}

	public List<Object> getFoldersAndFileEntries(long folderId) {
		Map<Long, List<Object>> foldersAndFileEntriesMap =
			_foldersAndFileEntriesMaps.get();

		return foldersAndFileEntriesMap.get(folderId);
	}

	public void putFileEntries(long folderId, List<FileEntry> fileEntries) {
		Map<Long, List<FileEntry>> fileEntriesMap = _fileEntriesMaps.get();

		fileEntriesMap.put(folderId, fileEntries);
	}

	public void putFileEntry(FileEntry fileEntry) {
		if (fileEntry == null) {
			return;
		}

		Map<Long, FileEntry> fileEntryMap = _fileEntryMaps.get();

		fileEntryMap.put(fileEntry.getFileEntryId(), fileEntry);
	}

	public void putFolder(Folder folder) {
		if (folder == null) {
			return;
		}

		Map<Long, Folder> folderMap = _folderMaps.get();

		folderMap.put(folder.getFolderId(), folder);
	}

	public void putFolders(long folderId, List<Folder> folders) {
		Map<Long, List<Folder>> foldersMap = _foldersMap.get();

		foldersMap.put(folderId, folders);
	}

	public void putFoldersAndFileEntries(
		long folderId, List<Object> foldersAndFileEntries) {

		Map<Long, List<Object>> foldersAndFileEntriesMap =
			_foldersAndFileEntriesMaps.get();

		foldersAndFileEntriesMap.put(folderId, foldersAndFileEntries);
	}

	private final ThreadLocal<Map<Long, List<FileEntry>>> _fileEntriesMaps = new AutoResetThreadLocal<Map<Long,List<FileEntry>>>(CMISRepository.class + "._fileEntriesMaps",new HashMap<>());
			
	private final ThreadLocal<Map<Long, FileEntry>> _fileEntryMaps = new AutoResetThreadLocal<>( CMISRepository.class + "._fileEntryMaps", new HashMap<>());
	private final ThreadLocal<Map<Long, Folder>> _folderMaps = new AutoResetThreadLocal<>( CMISRepository.class + "._folderMaps",new HashMap<>());
	private final ThreadLocal<Map<Long, List<Object>>> _foldersAndFileEntriesMaps = new AutoResetThreadLocal<>( CMISRepository.class + "._foldersAndFileEntriesMaps",new HashMap<>());
	private final ThreadLocal<Map<Long, List<Folder>>> _foldersMap = new AutoResetThreadLocal<>( CMISRepository.class + "._foldersMap",new HashMap<>());

}