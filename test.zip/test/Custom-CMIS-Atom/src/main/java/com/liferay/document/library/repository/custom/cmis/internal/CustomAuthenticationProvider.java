/**
 * 
 */
package com.liferay.document.library.repository.custom.cmis.internal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.chemistry.opencmis.client.bindings.spi.AbstractAuthenticationProvider;

import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.model.CompanyConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.repository.RepositoryException;
import com.liferay.portal.kernel.security.auth.CompanyThreadLocal;
import com.liferay.portal.kernel.security.auth.PrincipalThreadLocal;
import com.liferay.portal.kernel.service.CompanyLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;


public class CustomAuthenticationProvider extends AbstractAuthenticationProvider
{

	private static final Log LOGGER = LogFactoryUtil.getLog(CustomAuthenticationProvider.class);

	/* (non-Javadoc)
	 * @see org.apache.chemistry.opencmis.client.bindings.spi.StandardAuthenticationProvider#getHTTPHeaders(java.lang.String)
	 */
	@Override
	public Map<String, List<String>> getHTTPHeaders(final String url)
	{
		LOGGER.info("CustomAuthenticationProvider -------"+getLogin());
		final Map<String, List<String>> header = new HashMap<String, List<String>>();
		final List<String> user = new ArrayList<String>();
		try {
			user.add(getLogin());
		} catch(SystemException se) {
			LOGGER.error("SystemException in getting login name ->"+se.getMessage());
		}
		
		//header.put("SsoUserHeader", user);
		header.put("X-Alfresco-Remote-User", user);
		return header;
	}
	public String getLogin() throws SystemException {
		String login = PrincipalThreadLocal.getName();
		if (Validator.isNull(login) || GetterUtil.getLong(login) == 0 ) {
			return login;
		}

		try {
			Company company = CompanyLocalServiceUtil.getCompany(CompanyThreadLocal.getCompanyId());

			String authType = company.getAuthType();

			if (!authType.equals(CompanyConstants.AUTH_TYPE_ID)) {
				User user = UserLocalServiceUtil.getUser(GetterUtil.getLong(login));

				if (authType.equals(CompanyConstants.AUTH_TYPE_EA)) {
					login = user.getEmailAddress();
				}
				else if (authType.equals(CompanyConstants.AUTH_TYPE_SN)) {
					login = user.getScreenName();
				}
			}
		}
		catch (Exception e) {
			throw new RepositoryException(e);
		}

		return login;
	}
}
