/**
 * Copyright (c) 2000-2017 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.liferay.document.library.repository.custom.cmis.internal;

import com.liferay.portal.kernel.concurrent.ConcurrentReferenceValueHashMap;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.memory.FinalizeManager;
import com.liferay.portal.kernel.servlet.PortalSessionThreadLocal;
import com.liferay.portal.kernel.util.TransientValue;

import java.lang.ref.Reference;

import java.util.Enumeration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.servlet.http.HttpSession;

import org.apache.chemistry.opencmis.client.api.Session;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;

/**
 * @author Adolfo P??rez
 */
@Component(immediate = true, service = CMISSessionCache.class)
public class CMISSessionCache {

	public Session get(String key) {
		HttpSession httpSession = PortalSessionThreadLocal.getHttpSession();

		if (httpSession == null) {
			return null;
		}

		TransientValue<Session> transientValue =
			(TransientValue<Session>)httpSession.getAttribute(key);

		if (transientValue == null) {
			return null;
		}

		Object value = transientValue.getValue();

		if (value instanceof Session) {
			return (Session)value;
		}

		httpSession.removeAttribute(key);

		return null;
	}

	public void put(String key, Session session) {
		HttpSession httpSession = PortalSessionThreadLocal.getHttpSession();

		if (httpSession == null) {
			if (_log.isWarnEnabled()) {
				_log.warn("Unable to get HTTP session");
			}

			return;
		}

		httpSession.setAttribute(key, new TransientValue<>(session));

		_sessions.putIfAbsent(httpSession.getId(), httpSession);
	}

	@Deactivate
	protected void deactivate() {
		for (Map.Entry<String, HttpSession> entry : _sessions.entrySet()) {
			_clearSession(entry.getValue());
		}

		_sessions.clear();
	}

	private void _clearSession(HttpSession httpSession) {
		Enumeration<String> attributeNames = httpSession.getAttributeNames();

		while (attributeNames.hasMoreElements()) {
			String attributeName = attributeNames.nextElement();

			if (attributeName.startsWith(Session.class.getName())) {
				httpSession.removeAttribute(attributeName);

				break;
			}
		}
	}

	private static final Log _log = LogFactoryUtil.getLog(
		CMISSessionCache.class);

	private final ConcurrentMap<String, HttpSession> _sessions =
		new ConcurrentReferenceValueHashMap<>(
			new ConcurrentHashMap<String, Reference<HttpSession>>(),
			FinalizeManager.WEAK_REFERENCE_FACTORY);

}