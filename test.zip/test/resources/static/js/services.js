/* Services */
angular
		.module('angularApp.services', [])
		.value('version', '0.1')
		.service(
				'UtilService',
				function($location, $rootScope, $filter, $http, UserDataService) {

					// host of the alfresco server
					// uat: dmuat.edelcap.com
					this.contextRoot = function(){
						return "http://localhost:9090";
					};
					this.alfrescoContextRoot = function() {
						//return "http://10.250.18.171:8080";
						return "http://10.172.1.193:8080";
						// return "http://10.172.1.193:9090";
					};

					this.changeLocation = function(url, params) {
						if (params) {
							$location.path(url).search(params);
						} else {
							$location.search('id', null);
							$location.search('fileName', null);
							$location.path(url);
						}
						if (!$rootScope.$$phase) {
							$rootScope.$apply();
						}
					};

					this.contextRoot = function() {
						var path = location.pathname;
						var tempStr = path.split('/');
						if (window.location.href.indexOf(":8080") > -1) {
							return "/" + tempStr[1];
						} else {
							return "";
						}
					};

					this.doAjax = function(method, url, body, callback) {
						try {
							$http({
								method : method,
								url : url,
								data : body
							}).then(function successCallback(response) {
								callback(response);
							}, function errorCallback(response) {
								callback(response);
							});
						} catch (e) {
							console.log("doAjax: ", e);
						}
					};

					this.encodeText = function(text) {
						var encodedText = '';
						if (text != '' || text != null || text != undefined) {
							encodeText = btoa(btoa(text));
						} else {
							encodeText = btoa(text);
						}
						return encodeText;
					}

					this.decodeText = function(text) {
						var decodedText = '';
						if (text != '' || text != null || text != undefined) {
							encodeText = atob(atob(text));
						} else {
							encodeText = atob(text);
						}
						return encodeText;
					}

					this.showAlert = function(type, title, message, size,
							buttonColor) {
					};
				})
		.service('UserDataService', function() {
			this.userLogged = "test";
			this.userGroup = "RPA";
		})
		.service('ControllerService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {
					this.initController = function(scope) {
						if ($rootScope.authenticated) {
							scope.init();
						} else {
							this.checkIfAlreadyAuthenticated(function(
									authenticated) {
								if (authenticated) {
									scope.init();
								} else {
									// UtilService.changeLocation('/login');
									$state.go('login');
								}
							});
						}
					};

					this.checkIfAlreadyAuthenticated = function(callback) {
						if (sessionStorage.getItem('token')) {
							$rootScope.authenticated = true;
							callback($rootScope.authenticated);
						} else {
							$rootScope.authenticated = false;
							callback($rootScope.authenticated);
						}
					}
				})

		.service('DataService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {
					var savedData = {};

					this.setAllSearchedItems = function(item) {
						savedData = item;
					};

					this.getAllSearchedItems = function() {
						return savedData;
					};
				})

		.service('BroadcastService', function($rootScope) {
			this.message = '';
			this.broadcastItem = function(msg) {
				this.message = msg;
				$rootScope.$broadcast('handleBroadcast');
			};
			this.broadcast = function(event, msg) {
				this.message = msg;
				$rootScope.$broadcast(event);
			};
		})
		.service('CommonDataService',
				function($rootScope, UtilService, UserDataService, $http,
						$compile, $location, $window, $filter) {

					this.showAlertModal = function(title, text) {
					}
				})
				
				
		.service('LatestCreatedService',
				function($http, UtilService, siteId) {

					this.getPropertiesOf = function(docType) {
						var details = new Array();
						
						//for (var i = 0; i < docType.data.list.entries.length; i++) {
							var doc = docType.data.list.entries[0];
							doc = doc.entry;
							console.log("item", doc);
							console.log("item", doc.name);
							var createdDate = (new Date(doc.createdAt)).toDateString().split(" ");
							console.log("createdDate:",createdDate);
							var dayAndMonth = new Array();
							dayAndMonth.push({
										"day" : createdDate[2],
										"month" : createdDate[1],
										"year" : createdDate[3]
									});
							console.log("dayAndMonth",dayAndMonth);

							if (doc) {

								details.push({
											"displayName" : doc.name.slice(0,
													doc.name.lastIndexOf(".")),
											"name" : doc.name,
											"by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
													: '',
											"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
													: '',
											/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
													: '',*/
											"subCategory" : doc.properties["etl:Product"] ? doc.properties["etl:Product"]
													: ''|| doc.properties["etl:EdelMarketing"] ? doc.properties["etl:EdelMarketing"]
													: ''|| doc.properties["etl:PerformActuarialAnalysis"] ? doc.properties["etl:PerformActuarialAnalysis"]
													: ''|| doc.properties["etl:SalesProducts"] ? doc.properties["etl:SalesProducts"]
													: ''|| doc.properties["etl:OperationsAndServices"] ? doc.properties["etl:OperationsAndServices"]
													: ''|| doc.properties["etl:ManageInvestments"] ? doc.properties["etl:ManageInvestments"]
													: ''|| doc.properties["etl:AdminAndFacilities"] ? doc.properties["etl:AdminAndFacilities"]
													: ''|| doc.properties["etl:RiskManagement"] ? doc.properties["etl:RiskManagement"]
													: ''|| doc.properties["etl:Finance"] ? doc.properties["etl:Finance"]
													: ''|| doc.properties["etl:HRPolicy"] ? doc.properties["etl:HRPolicy"]
													: ''|| doc.properties["etl:InformationTechnology"] ? doc.properties["etl:InformationTechnology"]
													: ''|| doc.properties["etl:LegalAndCompliance"] ? doc.properties["etl:LegalAndCompliance"]
													: '',
											/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
													: '',*/
											"createdOn" : dayAndMonth[0].day +" "+dayAndMonth[0].month+" "+dayAndMonth[0].year
													,
											"id" : doc.id
										});
							}
						//}//close of for
						console.log("detailsArray : ", details);
						return details;
					}

					this.createSearchTerm = function(term) {
						var searchTerm
						searchTerm = '\"' + term
								/*+ '\" OR etl:ProductsAndMarketing:\"' + term*/
								/*+ '\" OR cm:name:\"' + term
								+ '\" OR cm:title:\"' + term
								+ '\" OR cm:description:\"' + term
								+ '\" OR cm:content:\"' + term*/

						var splitTerm = term.split(/\s+/);
						for (var j = 0; j < splitTerm.length; j++) {
							searchTerm = searchTerm + ' OR \"' + splitTerm[j]
									//+ '\" OR etl:ProductsAndMarketing:\"' + splitTerm[j]
									/*+ '\" OR cm:name:\"' + splitTerm[j]
									+ '\" OR cm:title:\"' + splitTerm[j]
									+ '\" OR cm:description:\"' + splitTerm[j]
									+ '\" OR cm:content:\"' + splitTerm[j]*/
									+ '\"';
						}
						return searchTerm;
					}

					this.getFilteredDocuments = function(searchTerm,categoryFilter, callback) {

						// generating the search term and passing this term in
						// the search API
						var term = '';

						if (searchTerm == '*') {
							term = '*';
						} else {
							term = this.createSearchTerm(searchTerm);
						}

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()+ "/alfresco/api/-default-/public/search/versions/1/search";
						var body = {
							"query" : {
								"query" : "SITE:'" + siteId + "' AND (" + term
										+ ")",
								"language" : "afts"
							},
							"paging" : {
								"maxItems" : 100,
								"skipCount" : 0
							},
							"include" : [ "properties" ],
							"filterQueries" : [
									{
										"query" : "TYPE:'cm:content'"
									},
									{
										"query" : "-cm:creator:system"
									},
									{
										"query" : "-TYPE:'fm:post'"
									},
									{
										"query" : "etl:Product:'"+ categoryFilter + "' ||"
												 +"etl:EdelMarketing:'"+ categoryFilter + "' ||"
												 +"etl:PerformActuarialAnalysis:'"+ categoryFilter + "' ||"
												 +"etl:SalesProducts:'"+ categoryFilter + "' ||"
												 +"etl:OperationsAndServices:'"+ categoryFilter +"' ||"
												 +"etl:ManageInvestments:'"+ categoryFilter + "' ||"
												 +"etl:AdminAndFacilities:'"+ categoryFilter + "' ||"
												 +"etl:RiskManagement:'"+ categoryFilter + "' ||"
												 +"etl:Finance:'"+ categoryFilter + "' ||"
												 +"etl:HumanResources:'"+ categoryFilter + "' ||"
												 +"etl:InformationTechnology:'"+ categoryFilter + "' ||"
												 +"etl:LegalAndCompliance:'"+ categoryFilter + "'"
									}
									
									/*,
									{
										"query" : "etl:PerformActuarialAnalysis:'"
												+ categoryFilter + "'"
									}*/],
									
									"sort" : [ {
										"type" : "FIELD",
										/*"field" : "cm:mimeType",*/
										"field" : "cm:created",
										/*"field" : "cm:modified",*/
										/*"ascending" : "true"*/
										"ascending" : "false"
									} ],
									
							'defaults' : {
								'textAttributes' : [ 'cm:content', 'cm:name',
										'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
							}
						};

						var headers = {
							authorization : "Basic " + btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							if (response.status === 200) {
								var entries = response.data.list.entries;
								callback(entries);
							} else {
								callback("error");
							}
						}, function errorCallback(response) {
							console.log(response);
							callback("error");
						});
					}
				})
				
		.service('AlertService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {

					this.notificationAlert = function(title, message) {
						modal({
							type : 'alert', // Type of Modal Box (alert |
							// confirm | prompt | success |
							// warning | error | info |
							// inverted | primary)
							title : title, // Modal Title
							text : message, // Modal HTML Content
							size : 'normal', // Modal Size (normal | large |
							// small)
							buttons : [ {
								text : 'OK', // Button Text
								val : 'ok', // Button Value
								eKey : true, // Enter Keypress
								addClass : 'btn-red btn-rounded', // Button
								onClick : function(dialog) {
									return true;
								}
							}, ],
							center : false, // Center Modal Box?
							autoclose : false, // Auto Close Modal Box?
							callback : null,
							onShow : function(r) {
							}, // After show Modal function
							closeClick : true, // Close Modal on click near the
							// box
							closable : true, // If Modal is closable
							theme : 'xenon', // Modal Custom Theme (xenon |
							// atlant | reseted)
							animate : false, // Slide animation
							background : 'rgba(0,0,0,0.35)', // Background
							// Color, it can
							// be null
							zIndex : 1050, // z-index
							buttonText : {
								ok : 'OK',
								yes : 'OK',
								cancel : 'Cancel'
							},
							template : '<div class="modal-box"><div class="modal-inner"><div class="modal-title"><a class="modal-close-btn"></a></div><div class="modal-text"></div><div class="modal-buttons"></div></div></div>',
							_classes : {
								box : '.modal-box',
								boxInner : ".modal-inner",
								title : '.modal-title',
								content : '.modal-text',
								buttons : '.modal-buttons',
								closebtn : '.modal-close-btn'
							}
						});
					}

					this.confirmationAlert = function(title, message,
							uploadType, action, username, jsonToPost) {
						var self = this;

						modal({
							type : 'confirm', // Type of Modal Box (alert |
							// confirm | prompt | success |
							// warning | error | info |
							// inverted | primary)
							title : title, // Modal Title
							text : message, // Modal HTML Content
							size : 'normal', // Modal Size (normal | large |
							// small)
							buttons : [ {
								text : 'OK', // Button Text
								val : 'ok', // Button Value
								eKey : true, // Enter Keypress
								addClass : 'btn-red btn-rounded', // Button
								// Classes
								// (btn-large
								// |
								// btn-small
								// |
								// btn-green
								// |
								// btn-light-green
								// |
								// btn-purple
								// |
								// btn-orange
								// |
								// btn-pink
								// |
								// btn-turquoise
								// |
								// btn-blue
								// |
								// btn-light-blue
								// |
								// btn-light-red
								// | btn-red
								// |
								// btn-yellow
								// |
								// btn-white
								// |
								// btn-black
								// |
								// btn-rounded
								// |
								// btn-circle
								// |
								// btn-square
								// |
								// btn-disabled)
								onClick : function(dialog) {
									return true;
								}
							}, ],
							center : false, // Center Modal Box?
							autoclose : false, // Auto Close Modal Box?
							callback : function(confirmationAction) {
								// if (confirmationAction == true) {
								// var actionUrl = null;
								// switch (action) {
								// case "save": {
								// actionUrl = "api/admin/save-records/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "overwrite": {
								// actionUrl = "api/admin/save-records/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "deleteAll": {
								// actionUrl = "api/admin/delete-all/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "undoDelete": {
								// actionUrl = "api/admin/undo-delete/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "update": {
								// actionUrl = "api/admin/update/"
								// + uploadType + "/" + username;
								// break;
								// }
								// default:
								// break;
								// }
								//
								// if (actionUrl != null
								// && actionUrl != undefined) {
								// if (jsonToPost == null) {
								// $http
								// .get(
								// UtilService
								// .contextRoot()
								// + actionUrl)
								// .success(
								// function(data) {
								// console
								// .log(
								// "Action: "
								// + action
								// + " Upload Type: "
								// + uploadType,
								// data);
								// self
								// .notificationAlert(
								// "Alert",
								// data[0]);
								// })
								// .error(
								// (function(data) {
								// alert("Error while "
								// + action
								// + " operation");
								// }));
								// } else {
								// $http
								// .post(
								// UtilService
								// .contextRoot()
								// + actionUrl,
								// jsonToPost)
								// .success(
								// function(data) {
								// console
								// .log(
								// "Action: "
								// + action
								// + " Upload Type: "
								// + uploadType,
								// data);
								// self
								// .notificationAlert(
								// "Alert",
								// data[0]);
								// })
								// .error(
								// (function(data) {
								// alert("Error while "
								// + action
								// + " operation");
								// }));
								// }
								// }
								// }
								// return true;
							},
							onShow : function(r) {
							}, // After show Modal function
							closeClick : true, // Close Modal on click near the
							// box
							closable : true, // If Modal is closable
							theme : 'xenon', // Modal Custom Theme (xenon |
							// atlant | reseted)
							animate : false, // Slide animation
							background : 'rgba(0,0,0,0.35)', // Background
							// Color, it can
							// be null
							zIndex : 1050, // z-index
							buttonText : {
								ok : 'OK',
								yes : 'OK',
								cancel : 'Cancel'
							},
							template : '<div class="modal-box"><div class="modal-inner"><div class="modal-title"><a class="modal-close-btn"></a></div><div class="modal-text"></div><div class="modal-buttons"></div></div></div>',
							_classes : {
								box : '.modal-box',
								boxInner : ".modal-inner",
								title : '.modal-title',
								content : '.modal-text',
								buttons : '.modal-buttons',
								closebtn : '.modal-close-btn'
							}
						});

					}

					this.kendoNotificationAlert = function(bodyContent) {
						var window = $("<div id='firstWindow'></div>")
								.appendTo(document.body).kendoWindow({
									width : "25%",
									height : "10%",
									title : "Alert",
									modal : true,
									visible : false,
								});
						window
								.data("kendoWindow")
								.content(
										bodyContent
												+ "<br><a id='closeButton' class='k-button' style='position: absolute; bottom : 5%; right: 3%' onclick='A(firstWindow);'>OK</a><script type='text/javascript'>function A(id) {$('#closeButton').closest('.k-window-content').data('kendoWindow').close();$('#firstWindow').remove();}</script>")
								.center().open();
					}
				})
		/*.service(
				'UploadService',
				function($location, $rootScope, $filter, $http, $q, siteId,
						UtilService) {

					this.uploadFileToUrl = function(file, alf_ticket,contentAuthor, subTheme) {
						// FormData, object of key/value pair for form fields
						// and values
						var fileFormData = new FormData();
						fileFormData.append('file', file);
						// fileFormData.append('filename', 'TestFile');
						// fileFormData.append('contentAuthor', contentAuthor);
						// fileFormData.append('uploadDirectoryPath',
						// uploadDirectoryPath);
						// fileFormData.append('uploadDocumentPath',
						// uploadDocumentPath);

						// var siteid='bsg';

						// var
						// uploadUrlRedirect="http://10.172.1.193:8080/alfresco/service/api/upload/?alf_ticket="+
						// $scope.token

						// window.location.replace(uploadUrl+"?uploadDocumentPath="+fileFormData);
						// window.location.replace(uploadUrl+"?uploadDocumentPath="+fileFormData);

						var deffered = $q.defer();

						
						 * $http.post(uploadUrl, fileFormData, {
						 * transformRequest : angular.identity, headers : {
						 * 'Content-Type' : undefined }
						 * 
						 * }).success(function(response) {
						 * deffered.resolve(response);
						 * 
						 * }).error(function(response) {
						 

						// -------------------------------ServiceCall-------------------------------------------------------------
						$http(
								{
									method : 'POST',
									// url:
									// 'http://10.172.1.193:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/-my-/children',
									url : 'http://10.172.1.193:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/-root-/children',
									// url:
									// 'http://10.172.1.193:8080/alfresco/service/',
									// relativePath:'/sites/BSG/documentLibrary/Technical';
									headers : {
										// 'Content-Type':
										// 'multipart/form-data',
										'Content-Type' : undefined,
										'authorization' : "Basic "
												+ btoa(alf_ticket)
									},

									data : {
										// alf_ticket:alf_ticket,
										// properties: {
										// cm:author :'contentAuthor'
										// },
										filedata : file,
										// siteId: 'bsg',
										// containerId: 'documentLibrary',
										// uploaddirectory :
										// '/sites/BSG/documentLibrary/Technical',
										overwrite : 'false',
										nodeType : 'cm:content',
										relativePath : 'Sites/BSG/documentLibrary/Technical',
										autorename : 'true',
										'cm:author' : contentAuthor,
										// edcc:SubTheme : 'Tools and
										// Techniques'
										'edcc:SubTheme' : subTheme

									},
									transformRequest : function(data,
											headersGetter) {
										var formData = new FormData();
										angular.forEach(data, function(value,
												key) {
											formData.append(key, value);
											// formData.append('cm:author',
											// contentAuthor);
											// formData.append('edcc:SubTheme',
											// subCategory);
											console.log('key', value);
											console.log('value', value);
										});

										console.log("formData++++++++++",
												formData);
										var headers = headersGetter();
										delete headers['Content-Type'];

										return formData;
									}
								}).success(function(data) {

						}).error(function(data, status) {
							// ---------------------------------------------------------------------------------------------

							deffered.reject(response);
						});

						return deffered.promise;
					}
				});*/
				
		

