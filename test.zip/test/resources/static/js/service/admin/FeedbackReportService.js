angularApp.service('FeedbackReportService', function($http, UtilService) {

	this.checkAdmin = function(username, callback) {
		var method = 'post';
		var url = UtilService.contextRoot() + "/api/admin/check";
		var body = {
			"username" : String(username),
		};

		var headers = {
			'Content-Type' : 'application/json'
		}

		$http({
			method : method,
			url : url,
			headers : headers,
			data : body
		}).then(function successCallback(response) {
			callback(response.data);
		}, function errorCallback(response) {
			callback(false);
		});
	}
})