package com.liferay.portal.security.sso.custom.api;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.liferay.portal.instances.service.PortalInstancesLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.BaseFilter;
import com.liferay.portal.kernel.servlet.BrowserSniffer;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.liferay.portal.kernel.servlet.HttpMethods;
import com.liferay.portal.kernel.util.GetterUtil;

import jcifs.ntlmssp.Type1Message;
import jcifs.ntlmssp.Type2Message;
import jcifs.util.Base64;

/**
 * A fix for LPS-3795 relating to IE6 (Internet Explorer 6) handling of HTTP
 * POSTs and NTLM authentication.
 *
 * @author Brian Wing Shun Chan
 */
@Component(
	immediate = true,
	property = {
		"after-filter=Custom SSO Ntlm Filter", "servlet-context-name=",
		"servlet-filter-name=Custom SSO Ntlm Post Filter", "url-pattern=/*"
	},
	service = Filter.class
)
public class CustomNtlmPostFilter extends BaseFilter{

	@Override
	public boolean isFilterEnabled(
		HttpServletRequest request, HttpServletResponse response) {
		String method = request.getMethod();
		if (!method.equals(HttpMethods.POST)) {
			return false;
		}
		return true;
	}

	@Override
	protected Log getLog() {
		return _log;
	}

	@Override
	protected void processFilter(
			HttpServletRequest request, HttpServletResponse response,
			FilterChain filterChain)
		throws Exception {

		String authorization = GetterUtil.getString(
			request.getHeader(HttpHeaders.AUTHORIZATION));

		if (authorization.startsWith("NTLM ")) {
			byte[] src = Base64.decode(authorization.substring(5));

			if (src[8] == 1) {
				Type1Message type1 = new Type1Message(src);

				Type2Message type2 = new Type2Message(type1, new byte[8], null);

				authorization = Base64.encode(type2.toByteArray());

				response.setHeader(
					HttpHeaders.WWW_AUTHENTICATE, "NTLM " + authorization);

				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.setContentLength(0);

				response.flushBuffer();

				return;
			}
		}

		processFilter(
			CustomNtlmPostFilter.class.getName(), request, response, filterChain);
	}

	private static final Log _log = LogFactoryUtil.getLog(CustomNtlmPostFilter.class);

	@Reference
	private BrowserSniffer _browserSniffer;


	@Reference
	private CustomNtlmFilter _ntlmFilter;

	@Reference
	private PortalInstancesLocalService _portalInstancesLocalService;

}
