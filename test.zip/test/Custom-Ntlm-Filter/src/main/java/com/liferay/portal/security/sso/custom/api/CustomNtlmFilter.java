package com.liferay.portal.security.sso.custom.api;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;

import com.liferay.portal.instances.service.PortalInstancesLocalService;
import com.liferay.portal.kernel.cache.PortalCache;
import com.liferay.portal.kernel.cache.SingleVMPool;
import com.liferay.portal.kernel.io.BigEndianCodec;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.security.SecureRandomUtil;
import com.liferay.portal.kernel.servlet.BaseFilter;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.security.sso.api.NetlogonConnectionManager;
import com.liferay.portal.security.sso.api.NtlmManager;
import com.liferay.portal.security.sso.api.NtlmServiceAccount;
import com.liferay.portal.security.sso.api.NtlmUserAccount;
import com.liferay.portal.security.sso.ntlm.constants.NtlmWebKeys;

import jcifs.Config;
import jcifs.util.Base64;


@Component(
		immediate = true,
		property = {
				"before-filter=Auto Login Filter", "dispatcher=FORWARD",
				"dispatcher=REQUEST", "servlet-context-name=",
			    "servlet-filter-name=Custom SSO Ntlm Filter", "url-pattern=/c/portal/login"
		},
	    service = Filter.class
)
public class CustomNtlmFilter extends BaseFilter {
    
	@Override
	public boolean isFilterEnabled(
		HttpServletRequest request, HttpServletResponse response) {
		boolean isFilterEnabled = Boolean.valueOf(PropsUtil.get("com.liferay.portal.security.sso.CustomNtlmFilter"));
		return isFilterEnabled;
	}
	
		
	protected NtlmManager getNtlmManager(long companyId) throws Exception {
		
		String domain = PropsUtil.get("com.liferay.portal.security.sso.domain");
		String domainController = PropsUtil.get("com.liferay.portal.security.sso.domainController");
		String domainControllerName = PropsUtil.get("com.liferay.portal.security.sso.domainControllerName");
		String serviceAccount = PropsUtil.get("com.liferay.portal.security.sso.serviceAccount");
		String servicePassword = PropsUtil.get("com.liferay.portal.security.sso.servicePassword");

        if( domainController != null && !isAllDigits(domainController)) {
        	domainController = findActiveController(domainController);
        	_log.info("domainController  :::"+domainController);
		}
		
		NtlmManager ntlmManager = _ntlmManagers.get(companyId);
		NtlmServiceAccount account = new NtlmServiceAccount(serviceAccount, servicePassword);
		if (ntlmManager == null) {
			ntlmManager = new NtlmManager(
				_netlogonConnectionManager, domain, domainController,
				domainControllerName, serviceAccount, servicePassword);

			_ntlmManagers.put(companyId, ntlmManager);
		}
		else {
			if (!Objects.equals(ntlmManager.getDomain(), domain) ||
				!Objects.equals(
					ntlmManager.getDomainController(), domainController) ||
				!Objects.equals(
					ntlmManager.getDomainControllerName(),
					domainControllerName) ||
				!Objects.equals(
					ntlmManager.getServiceAccount(), serviceAccount) ||
				!Objects.equals(
					ntlmManager.getServicePassword(), servicePassword)) {

				ntlmManager.setConfiguration(
					domain, domainController, domainControllerName,
					serviceAccount, servicePassword);
			}
		}
		
		
		_netlogonConnectionManager.connect(domainController, domainControllerName, account);

		return ntlmManager;
	}

	protected String getPortalCacheKey(HttpServletRequest request) {
		HttpSession session = request.getSession(false);

		if (session == null) {
			return request.getRemoteAddr();
		}

		return session.getId();
	}

	protected void processFilter(
			HttpServletRequest request, HttpServletResponse response,
			FilterChain filterChain)
		throws Exception {

		// Type 1 NTLM requests from browser can (and should) always immediately
		// be replied to with an Type 2 NTLM response, no matter whether we're
		// yet logging in or whether it is much later in the session.

		HttpSession session = request.getSession(false);

		long companyId = _portalInstancesLocalService.getCompanyId(request);

		String authorization = GetterUtil.getString(
			request.getHeader(HttpHeaders.AUTHORIZATION));

		if (authorization.startsWith("NTLM")) {
			NtlmManager ntlmManager = getNtlmManager(companyId);

			String portalCacheKey = getPortalCacheKey(request);

			byte[] src = Base64.decode(authorization.substring(5));

			if (src[8] == 1) {
				byte[] serverChallenge = new byte[8];

				BigEndianCodec.putLong(
					serverChallenge, 0, SecureRandomUtil.nextLong());

				byte[] challengeMessage = ntlmManager.negotiate(
					src, serverChallenge);

				authorization = Base64.encode(challengeMessage);

				response.setContentLength(0);
				response.setHeader(
					HttpHeaders.WWW_AUTHENTICATE, "NTLM " + authorization);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

				response.flushBuffer();

				_portalCache.put(portalCacheKey, serverChallenge);

				// Interrupt filter chain, send response. Browser will
				// immediately post a new request.

				return;
			}

			byte[] serverChallenge = _portalCache.get(portalCacheKey);

			if (serverChallenge == null) {
				response.setContentLength(0);
				response.setHeader(HttpHeaders.WWW_AUTHENTICATE, "NTLM");
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

				response.flushBuffer();

				return;
			}

			NtlmUserAccount ntlmUserAccount = null;

			try {
				ntlmUserAccount = ntlmManager.authenticate(
					src, serverChallenge);
			}
			catch (Exception e) {
				_log.error("Unable to perform NTLM authentication", e);
			}
			finally {
				_portalCache.remove(portalCacheKey);
			}

			if (ntlmUserAccount == null) {
				response.setContentLength(0);
				response.setHeader(HttpHeaders.WWW_AUTHENTICATE, "NTLM");
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

				response.flushBuffer();

				return;
			}

			if (_log.isDebugEnabled()) {
				_log.debug("NTLM remote user " + ntlmUserAccount.getUserName());
			}

			request.setAttribute(
				NtlmWebKeys.NTLM_REMOTE_USER, ntlmUserAccount.getUserName());

			if (session != null) {
				session.setAttribute(
					NtlmWebKeys.NTLM_USER_ACCOUNT, ntlmUserAccount);
			}
		}

		String path = request.getPathInfo();

		if ((path != null) && path.endsWith("/login")) {
			NtlmUserAccount ntlmUserAccount = null;

			if (session != null) {
				ntlmUserAccount = (NtlmUserAccount)session.getAttribute(
					NtlmWebKeys.NTLM_USER_ACCOUNT);
			}

			if (ntlmUserAccount == null) {
				response.setContentLength(0);
				response.setHeader(HttpHeaders.WWW_AUTHENTICATE, "NTLM");
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

				response.flushBuffer();

				return;
			}
			else {
				request.setAttribute(
					NtlmWebKeys.NTLM_REMOTE_USER,
					ntlmUserAccount.getUserName());
			}
		}

		processFilter(CustomNtlmPostFilter.class.getName(), request, response, filterChain);
	}

	
    protected String findActiveController(String hostname) throws UnknownHostException {
	   String activeController = "";
	   InetAddress[] iaddrs = InetAddress.getAllByName(hostname);
	    for (int x = 0; x < iaddrs.length; x++) {
	        try {
	           InetAddress activeIP = iaddrs[x]; 
	           activeController =  activeIP.getHostAddress();
	           InetSocketAddress addr = new InetSocketAddress(activeIP.getHostAddress(),139);
	           Socket controller = new Socket();
	           controller.connect(addr);
	           controller.setSoLinger(true,1);
	           controller.close();
	           break;
	        } catch (Exception e) {
	            continue;
	        } 
	    }
	    return activeController;
   }
    
    
    public boolean isAllDigits( String hostname ) {
        for (int i = 0; i < hostname.length(); i++) {
            if (Character.isDigit( hostname.charAt( i )) == false) {
                return false;
            }
        }
        return true;
    }
    
	@Override
	protected Log getLog() {
		return _log;
	}
	
		
	private static final Log _log = LogFactoryUtil.getLog(CustomNtlmFilter.class);
	
	
	private final Map<Long, NtlmManager> _ntlmManagers = new ConcurrentHashMap<>();
	
	private PortalCache<String, byte[]> _portalCache;
	
	
	@Reference(unbind = "-")
	public void setSingleVMPool(SingleVMPool singleVMPool) {
		_portalCache = (PortalCache<String, byte[]>)singleVMPool.getPortalCache(
			CustomNtlmFilter.class.getName());
	}

	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		for (Map.Entry<String, Object> entry : properties.entrySet()) {
			String key = entry.getKey();

			if (key.contains("jcifs.")) {
				String value = (String)entry.getValue();

				Config.setProperty(key, value);
			}
		}

		_ntlmManagers.clear();
	}

	@Reference
	private PortalInstancesLocalService _portalInstancesLocalService;
	
	private NetlogonConnectionManager _netlogonConnectionManager;
	
	@Reference(unbind = "-")
	public void setNetlogonConnectionManager(NetlogonConnectionManager netlogonConnectionManager) {
		_netlogonConnectionManager = netlogonConnectionManager;
	}

}