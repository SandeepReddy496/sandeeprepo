package com.edelweiss.bpri.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_MASTER", schema = "public")
public class User implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "username")
	private String userName;

	@Column(name = "domain")
	private String domain;

	@Column(name = "email")
	private String email;

	@Column(name = "enabled")
	private String enabled;

	@Column(name = "firstname")
	private String firstName;

	@Column(name = "lastname")
	private String lastName;

	@Column(name = "lob")
	private String lob;

	@Column(name = "usercode")
	private String userCode;

	@Column(name = "admin")
	private boolean isAdmin;

	public User(String username, String domain, String email, String enabled, String firstname, String lastname,
			String lob, String usercode, boolean isAdmin) {
		super();
		this.userName = username;
		this.domain = domain;
		this.email = email;
		this.enabled = enabled;
		this.firstName = firstname;
		this.lastName = lastname;
		this.lob = lob;
		this.userCode = usercode;
		this.isAdmin = isAdmin;
	}

	public String getUsername() {
		return userName;
	}

	public void setUsername(String username) {
		this.userName = username;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public String getFirstname() {
		return firstName;
	}

	public void setFirstname(String firstname) {
		this.firstName = firstname;
	}

	public String getLastname() {
		return lastName;
	}

	public void setLastname(String lastname) {
		this.lastName = lastname;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getUsercode() {
		return userCode;
	}

	public void setUsercode(String usercode) {
		this.userCode = usercode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public User() {
		super();
	}

	@Override
	public String toString() {
		return "User [username=" + userName + ", domain=" + domain + ", email=" + email + ", enabled=" + enabled
				+ ", firstname=" + firstName + ", lastname=" + lastName + ", lob=" + lob + ", usercode=" + userCode
				+ "]";
	}

}
