/* Services */
angular
		.module('angularApp.services', [])
		.value('version', '0.1')
		.service(
				'UtilService',
				function($location, $rootScope, $filter, $http, UserDataService) {

					// host of the alfresco server
					// uat: dmuat.edelcap.com
					this.alfrescoContextRoot = function() {
			return "http://dmuat.edelcap.com:8080";
					// return "http://10.172.1.193:9090";
					};

					this.changeLocation = function(url, params) {
						if (params) {
							$location.path(url).search(params);
						} else {
							$location.search('id', null);
							$location.search('fileName', null);
							$location.path(url);
						}
						if (!$rootScope.$$phase) {
							$rootScope.$apply();
						}
					};

					this.contextRoot = function() {
						var path = location.pathname;
						var tempStr = path.split('/');
						if (window.location.href.indexOf(":8080") > -1) {
							return "/" + tempStr[1];
						} else {
							return "";
						}
					};

					this.doAjax = function(method, url, body, callback) {
						try {
							$http({
								method : method,
								url : url,
								data : body
							}).then(function successCallback(response) {
								callback(response);
							}, function errorCallback(response) {
								callback(response);
							});
						} catch (e) {
							console.log("doAjax: ", e);
						}
					};

					this.encodeText = function(text) {
						var encodedText = '';
						if (text != '' || text != null || text != undefined) {
							encodeText = btoa(btoa(text));
						} else {
							encodeText = btoa(text);
						}
						return encodeText;
					}

					this.decodeText = function(text) {
						var decodedText = '';
						if (text != '' || text != null || text != undefined) {
							encodeText = atob(atob(text));
						} else {
							encodeText = atob(text);
						}
						return encodeText;
					}

					this.showAlert = function(type, title, message, size,
							buttonColor) {
					};
				})
		.service('UserDataService', function() {
			this.userLogged = "test";
			this.userGroup = "RPA";
		})
		.service(
				'ControllerService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {
					this.initController = function(scope) {
						if ($rootScope.authenticated) {
							scope.init();
						} else {
							this.checkIfAlreadyAuthenticated(function(
									authenticated) {
								if (authenticated) {
									scope.init();
								} else {
									// UtilService.changeLocation('/login');
									$state.go('login');
								}
							});
						}
					};

					this.checkIfAlreadyAuthenticated = function(callback) {
						if (sessionStorage.getItem('token')) {
							$rootScope.authenticated = true;
							callback($rootScope.authenticated);
						} else {
							$rootScope.authenticated = false;
							callback($rootScope.authenticated);
						}
					}
				})

		.service(
				'DataService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {
					var savedData = {};

					this.setAllSearchedItems = function(item) {
						savedData = item;
					};

					this.getAllSearchedItems = function() {
						return savedData;
					};
				})

		.service('BroadcastService', function($rootScope) {
			this.message = '';
			this.broadcastItem = function(msg) {
				this.message = msg;
				$rootScope.$broadcast('handleBroadcast');
			};
			this.broadcast = function(event, msg) {
				this.message = msg;
				$rootScope.$broadcast(event);
			};
		})
		.service(
				'CommonDataService',
				function($rootScope, UtilService, UserDataService, $http,
						$compile, $location, $window, $filter) {

					this.showAlertModal = function(title, text) {
					}
				})
		.service(
				'AlertService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {

					this.notificationAlert = function(title, message) {
						modal({
							type : 'alert', // Type of Modal Box (alert |
							// confirm | prompt | success |
							// warning | error | info |
							// inverted | primary)
							title : title, // Modal Title
							text : message, // Modal HTML Content
							size : 'normal', // Modal Size (normal | large |
							// small)
							buttons : [ {
								text : 'OK', // Button Text
								val : 'ok', // Button Value
								eKey : true, // Enter Keypress
								addClass : 'btn-red btn-rounded', // Button
								onClick : function(dialog) {
									return true;
								}
							}, ],
							center : false, // Center Modal Box?
							autoclose : false, // Auto Close Modal Box?
							callback : null,
							onShow : function(r) {
							}, // After show Modal function
							closeClick : true, // Close Modal on click near the
							// box
							closable : true, // If Modal is closable
							theme : 'xenon', // Modal Custom Theme (xenon |
							// atlant | reseted)
							animate : false, // Slide animation
							background : 'rgba(0,0,0,0.35)', // Background
							// Color, it can
							// be null
							zIndex : 1050, // z-index
							buttonText : {
								ok : 'OK',
								yes : 'OK',
								cancel : 'Cancel'
							},
							template : '<div class="modal-box"><div class="modal-inner"><div class="modal-title"><a class="modal-close-btn"></a></div><div class="modal-text"></div><div class="modal-buttons"></div></div></div>',
							_classes : {
								box : '.modal-box',
								boxInner : ".modal-inner",
								title : '.modal-title',
								content : '.modal-text',
								buttons : '.modal-buttons',
								closebtn : '.modal-close-btn'
							}
						});
					}

					this.confirmationAlert = function(title, message,
							uploadType, action, username, jsonToPost) {
						var self = this;

						modal({
							type : 'confirm', // Type of Modal Box (alert |
							// confirm | prompt | success |
							// warning | error | info |
							// inverted | primary)
							title : title, // Modal Title
							text : message, // Modal HTML Content
							size : 'normal', // Modal Size (normal | large |
							// small)
							buttons : [ {
								text : 'OK', // Button Text
								val : 'ok', // Button Value
								eKey : true, // Enter Keypress
								addClass : 'btn-red btn-rounded', // Button
								// Classes
								// (btn-large
								// |
								// btn-small
								// |
								// btn-green
								// |
								// btn-light-green
								// |
								// btn-purple
								// |
								// btn-orange
								// |
								// btn-pink
								// |
								// btn-turquoise
								// |
								// btn-blue
								// |
								// btn-light-blue
								// |
								// btn-light-red
								// | btn-red
								// |
								// btn-yellow
								// |
								// btn-white
								// |
								// btn-black
								// |
								// btn-rounded
								// |
								// btn-circle
								// |
								// btn-square
								// |
								// btn-disabled)
								onClick : function(dialog) {
									return true;
								}
							}, ],
							center : false, // Center Modal Box?
							autoclose : false, // Auto Close Modal Box?
							callback : function(confirmationAction) {
								// if (confirmationAction == true) {
								// var actionUrl = null;
								// switch (action) {
								// case "save": {
								// actionUrl = "api/admin/save-records/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "overwrite": {
								// actionUrl = "api/admin/save-records/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "deleteAll": {
								// actionUrl = "api/admin/delete-all/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "undoDelete": {
								// actionUrl = "api/admin/undo-delete/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "update": {
								// actionUrl = "api/admin/update/"
								// + uploadType + "/" + username;
								// break;
								// }
								// default:
								// break;
								// }
								//
								// if (actionUrl != null
								// && actionUrl != undefined) {
								// if (jsonToPost == null) {
								// $http
								// .get(
								// UtilService
								// .contextRoot()
								// + actionUrl)
								// .success(
								// function(data) {
								// console
								// .log(
								// "Action: "
								// + action
								// + " Upload Type: "
								// + uploadType,
								// data);
								// self
								// .notificationAlert(
								// "Alert",
								// data[0]);
								// })
								// .error(
								// (function(data) {
								// alert("Error while "
								// + action
								// + " operation");
								// }));
								// } else {
								// $http
								// .post(
								// UtilService
								// .contextRoot()
								// + actionUrl,
								// jsonToPost)
								// .success(
								// function(data) {
								// console
								// .log(
								// "Action: "
								// + action
								// + " Upload Type: "
								// + uploadType,
								// data);
								// self
								// .notificationAlert(
								// "Alert",
								// data[0]);
								// })
								// .error(
								// (function(data) {
								// alert("Error while "
								// + action
								// + " operation");
								// }));
								// }
								// }
								// }
								// return true;
							},
							onShow : function(r) {
							}, // After show Modal function
							closeClick : true, // Close Modal on click near the
							// box
							closable : true, // If Modal is closable
							theme : 'xenon', // Modal Custom Theme (xenon |
							// atlant | reseted)
							animate : false, // Slide animation
							background : 'rgba(0,0,0,0.35)', // Background
							// Color, it can
							// be null
							zIndex : 1050, // z-index
							buttonText : {
								ok : 'OK',
								yes : 'OK',
								cancel : 'Cancel'
							},
							template : '<div class="modal-box"><div class="modal-inner"><div class="modal-title"><a class="modal-close-btn"></a></div><div class="modal-text"></div><div class="modal-buttons"></div></div></div>',
							_classes : {
								box : '.modal-box',
								boxInner : ".modal-inner",
								title : '.modal-title',
								content : '.modal-text',
								buttons : '.modal-buttons',
								closebtn : '.modal-close-btn'
							}
						});

					}

					this.kendoNotificationAlert = function(bodyContent) {
						var window = $("<div id='firstWindow'></div>")
								.appendTo(document.body).kendoWindow({
									width : "25%",
									height : "10%",
									title : "Alert",
									modal : true,
									visible : false,
								});
						window
								.data("kendoWindow")
								.content(
										bodyContent
												+ "<br><a id='closeButton' class='k-button' style='position: absolute; bottom : 5%; right: 3%' onclick='A(firstWindow);'>OK</a><script type='text/javascript'>function A(id) {$('#closeButton').closest('.k-window-content').data('kendoWindow').close();$('#firstWindow').remove();}</script>")
								.center().open();
					}
				});
