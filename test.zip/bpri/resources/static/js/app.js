'use strict';

var angularApp = angular.module('angularApp', [ 'ui.router', 'ngResource',
		'ngRoute', 'angularApp.directives', 'angularApp.services',
		// 'angularApp.ViewService', 'angularApp.SearchService',
		'angulartics', 'angulartics.piwik' ]);

angularApp.constant("siteId", "corporate-controller-bpri")

angularApp.config(function($stateProvider, $routeProvider, $httpProvider) {

	$stateProvider.state('login', {
		url : '/login',
		templateUrl : 'html/login.html',
		controller : 'LoginController'

	}).state('home', {
		url : '/home',
		templateUrl : 'html/home.html',
		controller : 'HomeController'

	})

	.state('search', {
		url : '/search?:term',
		templateUrl : 'html/search.html',
		controller : 'SearchController'
	})

	.state('filter-search', {
		url : '/filter-search?:subTheme?:term',
		templateUrl : 'html/filter-search.html',
		controller : 'FilterSearchController'
	})

	.state('view', {
		url : '/view?:id?:fileName?:author',
		templateUrl : 'html/view.html',
		controller : 'ViewController'
	})

	.state('feedback-report', {
		url : '/admin/feedback-report',
		templateUrl : 'html/admin/feedback-report.html',
		controller : 'FeedbackReportController'
	})

	.state('about', {
		url : '/about',
		templateUrl : 'html/about.html',
		controller : 'AboutController'

	})

	$httpProvider.defaults.headers.common['Authorization'] = 'Basic '
			+ btoa(sessionStorage.getItem('token'));
});
