'use strict';

var ViewController = angularApp
		.controller(
				'ViewController',
				function ViewController($scope, $rootScope, $http, $state,
						$location, $routeParams, $stateParams, siteId,
						UtilService, AlertService, ControllerService,
						DataService, ViewService) {

					$scope.alfrescoContext = UtilService.alfrescoContextRoot();
					$scope.token = sessionStorage.getItem('token');

					$scope.deleteComment = function(event) {
						var nodeId = $stateParams.id;
						var commentId = event.target.id;

						var method = 'delete';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ nodeId + "/comments/" + commentId;
						var body = {};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							console.log(response);
							if (response.status === 204) {
								console.log('comment deleted: ', response);

								var comments = $scope.allComments;
								for (var i = 0; i < comments.length; i++) {
									var item = comments[i];
									if (item.id === commentId) {
										$scope.allComments.splice(i, 1);
										break;
									}
								}
								if ($scope.allComments.length > 0) {
									$scope.noComments = false;
								} else {
									$scope.noComments = true;
								}
							} else {
								console.log('status != 200');
							}
						}, function errorCallback(response) {
							console.log('error');
						});
					}

					var writeComment = function(id, content, callback) {
						if (content) {

							var method = 'post';
							var url = UtilService.alfrescoContextRoot()
									+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
									+ id
									+ "/comments?fields=id,content,canDelete,createdBy";
							var body = {
								"content" : content
							};

							var headers = {
								authorization : "Basic "
										+ btoa(sessionStorage.getItem('token'))
							}

							$http({
								method : method,
								url : url,
								headers : headers,
								data : body
							})
									.then(
											function successCallback(response) {
												if (response.status === 201) {
													var entry = response.data.entry;
													$scope.allComments
															.splice(
																	0,
																	0,
																	{
																		"id" : entry.id,
																		"comment" : entry.content,
																		"canDelete" : entry.canDelete,
																		"createdBy" : entry.createdBy.firstName
																				+ " "
																				+ entry.createdBy.lastName
																	});
													$scope.noComments = false;
												} else {
													console
															.log('status != 200');
												}
												callback(true);
											},
											function errorCallback(response) {
												console.log('error');
												callback(true);
											});
						}
						$scope.commentText = '';
					}

					var getAllComments = function(id) {
						$scope.allComments = [];
						var method = 'get';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ id
								+ "/comments?fields=id,content,canDelete,createdBy";
						var body = {};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(
										function successCallback(response) {
											if (response.status === 200) {
												console
														.log(
																'all comments: ',
																response.data.list.entries);

												var comments = new Array();
												var entries = response.data.list.entries;
												if (entries.length > 0) {
													for (var i = 0; i < entries.length; i++) {
														var entry = entries[i].entry;
														comments
																.push({
																	"id" : entry.id,
																	"comment" : entry.content,
																	"canDelete" : entry.canDelete,
																	"createdBy" : entry.createdBy.firstName
																			+ " "
																			+ entry.createdBy.lastName
																});
													}
													$scope.allComments = comments;
													$scope.noComments = false;
												} else {
													console
															.log("No comments found");
													// comments
													// .push({
													// "comment" : "(No
													// comments)"
													// });
													// $scope.allComments =
													// comments;
													$scope.noComments = true;
												}

											} else {
												console.log('status != 200');
											}
										}, function errorCallback(response) {
											console.log('error');
										});
					}

					$scope.onCommentClick = function() {
						var id = $scope.id;
						var commentText = $scope.commentText.trim();

						if (commentText != null || commentText != undefined
								|| commentText != '') {
							ViewService
									.comment(
											id,
											commentText,
											function(entry) {
												// setting the new comment in
												// scope's all comment list
												$scope.allComments
														.splice(
																0,
																0,
																{
																	"id" : entry.id,
																	"comment" : entry.content,
																	"canDelete" : entry.canDelete,
																	"createdBy" : entry.createdBy.firstName
																			+ " "
																			+ entry.createdBy.lastName
																});

												if ($scope.allComments.length > 0) {
													$scope.noComments = false;
												} else {
													$scope.noComments = true;
												}
											});
						}
						// setting the scope text to null on frontend
						$scope.commentText = '';
					}

					var deleteLike = function(id) {
						$scope.likeStatus = !($scope.likeStatus);
						$scope.totalLikes = $scope.totalLikes - 1;

						var method = 'delete';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ id + "/ratings/likes";
						var body = {};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							$scope.likeStatus = false;
							if (response.status === 200) {
								console.log('status 200');
							} else {
								console.log('status != 200');
							}
						}, function errorCallback(response) {
							console.log('error');
						});

					}

					var postLike = function(id) {
						$scope.likeStatus = !($scope.likeStatus);
						$scope.totalLikes = $scope.totalLikes + 1;
						var myRating = $scope.likeStatus;

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ id + "/ratings";
						var body = {
							"id" : "likes",
							"myRating" : true
						};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							$scope.likeStatus = true;
							if (response.status === 200) {
								console.log(response);

							} else {
								console.log(response);
							}
						}, function errorCallback(response) {
							console.log('error');
						});
					}

					var getAllLikes = function(id) {
						var method = 'get';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ id + "/ratings/likes";
						var body = {};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(
										function successCallback(response) {
											if (response.status === 200) {
												$scope.totalLikes = response.data.entry.aggregate.numberOfRatings;
												var status = response.data.entry.myRating;
												if (!status) {
													status = false;
												}
												$scope.likeStatus = status;
											} else {
												console.log('error != 200');
											}
										}, function errorCallback(response) {
											console.log('error');
										});
					}

					$scope.onLikeClick = function() {
						var id = $scope.id;
						if ($scope.likeStatus) {
							deleteLike(id);
						} else {
							postLike(id);
						}

					}

					var generateMoreBestPractices = function(maxItems,
							fileName, moreBestPractices) {

						var generatedBestPractices = new Array();
						var searchTerm = "SITE:'" + siteId + "' AND (*)"; // \"corporate-controller-bpri\"
						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/search/versions/1/search";

						var body = {
							"query" : {
								"query" : searchTerm,
								"language" : "afts"
							},
							"paging" : {
								"maxItems" : maxItems,
								"skipCount" : 0
							},
							"include" : [ "properties" ],
							"filterQueries" : [ {
								"query" : "TYPE:'cm:content'"
							}, {
								"query" : "-cm:creator:system"
							}, {
								"query" : "-TYPE:'fm:post'"
							}, {
								"query" : "-cm:name:'" + fileName + "'"
							} ]
						}
						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(
										function successCallback(response) {
											console
													.log(
															"Generate more best practices: ",
															response);
											var entries = response.data.list.entries;

											for (var i = 0; i < entries.length; i++) {
												var entry = entries[i].entry;
												var name = entry.name;
												var id = entry.id;
												generatedBestPractices
														.push({
															"id" : id,
															"name" : name,
															"by" : entry.properties["cm:author"] ? entry.properties["cm:author"]
																	: '',
															"category" : entry.properties["edcc:Theme"] ? entry.properties["edcc:Theme"]
																	: '',
															"subCategory" : entry.properties["edcc:RetailWholesale"] ? entry.properties["edcc:RetailWholesale"]
																	: '',
															"sbu" : entry.properties["edcc:sbu"] ? entry.properties["edcc:sbu"]
																	: ''
														});
											}

											// $scope.generatedBestPractices =
											// generatedBestPractices;

											if (maxItems != 5) {
												for (var i = 0; i < generatedBestPractices.length; i++) {
													moreBestPractices
															.push(generatedBestPractices[i]);
												}
												$scope.moreBestPractices = moreBestPractices;
											} else {
												$scope.moreBestPractices = generatedBestPractices;
											}

										}, function errorCallback(response) {
											console.log('error');
										});
					}

					var findTopFiveDocuments = function(id, fileName,
							searchTerm) {

						searchTerm = "SITE:'" + siteId + "' AND (" // \"corporate-controller-bpri\"
								+ searchTerm + ")";

						if (id != null) {
							var method = 'post';
							var url = UtilService.alfrescoContextRoot()
									+ "/alfresco/api/-default-/public/search/versions/1/search";
							var body = {
								"query" : {
									"query" : searchTerm,
									"language" : "afts"
								},
								"paging" : {
									"maxItems" : 5,
									"skipCount" : 0
								},
								"include" : [ "properties" ],
								/* "path" */
								/* "aspectNames" */
								"filterQueries" : [ {
									"query" : "TYPE:'cm:content'"
								}, {
									"query" : "-cm:creator:system"
								}, {
									"query" : "-TYPE:'fm:post'"
								},
								// excluding the file which is on
								// view
								{
									"query" : "-cm:name:'" + fileName + "'"
								}
								// ,
								// {
								// "query" :
								// "ANCESTOR:'workspace://SpacesStore/9553fe6f-0c15-4996-928c-dc919b30ab13'"
								// }
								],
								/* "query" : "cm:creator:tanmaysalve" */
								"sort" : [ {
									"type" : "FIELD",
									"field" : "cm:mimeType",
									"ascending" : "true"
								} ],
								'defaults' : {
									'textAttributes' : [ 'cm:content',
											'cm:name', 'cm:description',
											'cm:title' ],
									'defaultFTSOperator' : 'OR',
									'defaultFTSFieldOperator' : 'OR',
									'namespace' : 'cm',
									'defaultFieldName' : '\"/\"'
								}
							};

							var headers = {
								authorization : "Basic "
										+ btoa(sessionStorage.getItem('token'))
							}

							$http({
								method : method,
								url : url,
								headers : headers,
								data : body
							})
									.then(
											function successCallback(response) {
												if (response.status === 200) {
													var moreBestPractices = new Array();

													if (response.data.list.entries.length > 0) {
														var entries = response.data.list.entries;
														console.log(
																"entries: BP ",
																entries);
														for (var i = 0; i < entries.length; i++) {
															var entry = entries[i].entry;
															var name = entry.name;
															var id = entry.id;

															moreBestPractices
																	.push({
																		"id" : id,
																		"name" : name,
																		"by" : entry.properties["cm:author"] ? entry.properties["cm:author"]
																				: '',
																		"category" : entry.properties["edcc:Theme"] ? entry.properties["edcc:Theme"]
																				: '',
																		"subCategory" : entry.properties["edcc:SubTheme"] ? entry.properties["edcc:SubTheme"]
																				: '',
																		"sbu" : entry.properties["edcc:sbu"] ? entry.properties["edcc:sbu"]
																				: ''
																	});
														}
														/*
														 * setting response on
														 * UI
														 */
														if (response.data.list.entries.length < 5) {
															var itemCount = response.data.list.entries.length;
															generateMoreBestPractices(
																	5 - itemCount,
																	fileName,
																	moreBestPractices);

														} else {
															$scope.moreBestPractices = moreBestPractices;
														}
													} else {
														console.log('no items');
														// getting '*' search &
														// setting on UI
														generateMoreBestPractices(
																5, fileName,
																moreBestPractices);
													}
												} else {
													console.log('code != 200',
															response);
												}
											},
											function errorCallback(response) {
												console.log('error');
											});
						}
					}

					var createSearchTerm = function(term) {
						var searchTerm
						searchTerm = '\"' + term + '\" OR cm:name:\"' + term
								+ '\" OR cm:title:\"' + term
								+ '\" OR cm:description:\"' + term
								+ '\" OR cm:content:\"' + term

						var splitTerm = term.split(/\s+/);
						for (var j = 0; j < splitTerm.length; j++) {
							searchTerm = searchTerm + ' OR \"' + splitTerm[j]
									+ '\" OR cm:name:\"' + splitTerm[j]
									+ '\" OR cm:title:\"' + splitTerm[j]
									+ '\" OR cm:description:\"' + splitTerm[j]
									+ '\" OR cm:content:\"' + splitTerm[j]
									+ '\"';
						}
						return searchTerm;
					}

					var getMoreBestPractices = function(id, fileName) {
						var searchTerm = createSearchTerm(fileName);
						findTopFiveDocuments(id, fileName, searchTerm);
					}

					var previewDocument = function(id, fileName) {
						var fileExtension = fileName.slice((fileName
								.lastIndexOf(".") + 1), fileName.length);

						var viewContent = $('#viewContent');
						var htmlContent = '';
						var encodedFilePath = '';

						if (fileExtension != undefined || fileExtension != null) {

							if ((fileExtension.trim().toLowerCase() === 'pdf')) {
								encodedFilePath = encodeURIComponent(UtilService
										.alfrescoContextRoot()
										+ "/alfresco/service/api/node/workspace/SpacesStore/"
										+ id
										+ "/content/pdf?c=force&alf_ticket="
										+ $scope.token);

								htmlContent = "<iframe allowfullscreen webkitallowfullscreen mozallowfullscreen=true	class='banner banner2' src='js/lib/pdfjs/web/viewer.html?file="
										+ encodedFilePath + "'></iframe>";

							} else if (fileExtension.trim().toLowerCase() === 'mp4'
									|| fileExtension.trim().toLowerCase() === 'ogv'
									|| fileExtension.trim().toLowerCase() === 'webm') {
								encodedFilePath = (UtilService
										.alfrescoContextRoot()
										+ "/alfresco/service/api/node/workspace/SpacesStore/"
										+ id
										+ "/content/pdf?c=force&alf_ticket=" + $scope.token);

								htmlContent = "<video controls autoplay controlsList='nodownload' class='banner'> <source src='"
										+ encodedFilePath
										+ "' type='video/mp4'> </video>";
							} else {
								encodedFilePath = encodeURIComponent(UtilService
										.alfrescoContextRoot()
										+ "/alfresco/service/api/node/workspace/SpacesStore/"
										+ id
										+ "/content/thumbnails/pdf?c=force&alf_ticket="
										+ $scope.token + "#page=1");

								htmlContent = "<iframe allowfullscreen webkitallowfullscreen mozallowfullscreen=true class='banner banner2' src='js/lib/pdfjs/web/viewer.html?file="
										+ encodedFilePath + "'></iframe>";
							}

						} else {
							htmlContent = "<h2> CANNOT PREVIEW</h2> ";
						}

						viewContent.find('#content').html(htmlContent);
					}

					var setDetails = function(id, fileName, author, sbu,
							description, dayAndMonth) {
						$scope.view = new Array();
						$scope.id = id;
						$scope.view.name = fileName ? fileName : '';
						$scope.view.author = author ? author : '';
						$scope.view.sbu = sbu ? sbu : '';
						$scope.view.description = description ? description
								: ''
						$scope.view.day = dayAndMonth[0].day ? dayAndMonth[0].day
								: '00';
						$scope.view.month = dayAndMonth[0].month ? dayAndMonth[0].month
								: 'YYY';
					}

					var init = function() {
						var id = $stateParams.id;
						var fileName = $stateParams.fileName;
						var author = $stateParams.author;

						if (id === null || id === undefined || id === '') {
							$state.go('home');
						} else {
							var method = 'get';
							var url = UtilService.alfrescoContextRoot()
									+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
									+ id;
							var body = {};

							var headers = {
								authorization : "Basic "
										+ btoa(sessionStorage.getItem('token'))
							}

							$http({
								method : method,
								url : url,
								headers : headers,
								data : body
							})
									.then(
											function successCallback(response) {
												$scope.likeStatus = true;
												if (response.status === 200) {

													var createdDate = (new Date(
															response.data.entry.createdAt))
															.toDateString()
															.split(" ");
													// var category =
													// response.data.entry.properties["edcc:Theme"];
													// var subCategory =
													// response.data.entry.properties["edcc:RetailWholesale"];
													var sbu = response.data.entry.properties["edcc:sbu"];
													var description = response.data.entry.properties["cm:description"];

													var dayAndMonth = new Array();
													dayAndMonth
															.push({
																"day" : createdDate[2],
																"month" : createdDate[1]
															});

													setDetails(id, fileName,
															author, sbu,
															description,
															dayAndMonth);

													previewDocument(id,
															fileName);

													getMoreBestPractices(id,
															fileName);

													getAllLikes(id);
													getAllComments(id);
												} else {
													console.log(response);
												}
											},
											function errorCallback(response) {
												console.log('error');
												$state.go('login');
											});
						}
					}

					angular.element(document).ready(
							function() {
								console.log("**********ViewController*******");
								$(this).scrollTop(0);
								if (sessionStorage.getItem('token')) {
									init();
								} else {
									sessionStorage.setItem('redirectUrl',
											$location.absUrl());
									console.log("View Unauthenticated");
									$state.go('login');
								}
							});
				});