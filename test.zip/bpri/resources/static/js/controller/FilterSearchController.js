'use strict';

var FilterSearchController = angularApp.controller('FilterSearchController',
		function FilterSearchController($scope, $state, $stateParams,
				FilterSearchService, UtilService) {

			$scope.alfrescoContext = UtilService.alfrescoContextRoot();
			$scope.token = sessionStorage.getItem('token');

			var init = function() {
				var searchTerm = $stateParams.term;
				var subThemeFilter = $stateParams.subTheme;

				FilterSearchService.getFilteredDocuments(searchTerm,
						subThemeFilter, function(response) {

							if (response != 'error') {
								$scope.allItemsCount = response.length;
								$scope.subThemeFilter = subThemeFilter;
								if (searchTerm != '*') {
									$scope.searchTerm = searchTerm + " in ";
								}
								$scope.allItemsDetails = FilterSearchService
										.getPropertiesOf(response);
							}
						});
			}

			angular.element(document).ready(function() {
				console.log("**********FilterSearchController*******");
				$(this).scrollTop(0);

				if (sessionStorage.getItem('token')) {
					init();
				} else {
					sessionStorage.setItem('redirectUrl', $location.absUrl());
					console.log("FilterSearch Unauthenticated");
					$state.go('login');
				}
			});
		})