'use strict';

var IndexController = angularApp
		.controller(
				'IndexController',
				function IndexController($scope, $rootScope, $state, $http,
						$location, $window, UserDataService, UtilService,
						ControllerService, CommonDataService) {

					$scope.onLogoutClick = function() {
						var method = 'delete';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/authentication/versions/1/tickets/-me-"
						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}
						var body = {};

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							console.log("response::::", response);
						}, function errorCallback(response) {
							console.log("response::::", response);
						});
					}

					$scope.onFeedbackSubmitCommentClick = function() {
						if (sessionStorage.getItem('token')) {
							var text = $scope.feedbackText;
							var feedbackType = $scope.feedbackDropdownSelectedOption.name;
							if (text != null || text != undefined || text != ''
									|| text != "") {
								var urlOnPage = $location;
								var userId = sessionStorage.getItem('userId');
								var method = 'post';
								var url = UtilService.contextRoot()
										+ "/api/feedback";
								text = text.trim();
								var body = {
									"username" : String(userId),
									"url" : String(urlOnPage.$$absUrl),
									"feedbackText" : String(text),
									"feedbackType" : String(feedbackType)
								};

								var headers = {
									'Content-Type' : 'application/json'
								}

								$http({
									method : method,
									url : url,
									headers : headers,
									data : body
								}).then(function successCallback(response) {
									console.log(response);
									if (response.status === 200) {
										console.log('status 200');
									} else {
										console.log('status != 200');
									}
								}, function errorCallback(response) {
									console.log('error', response);
								});
							}
							$scope.feedbackText = '';
							$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
							document.getElementById("#myModal");
						} else {
							state.go('login');
						}
					}

					$scope.onMainSearchClick = function() {
						var text = $scope.mainSearchText;
						$scope.selectedMenuItem = '';
						$state.go('search', {
							term : text
						});
					}

					$scope.filterSubTheme = function(subThemeFilter) {
						var subTheme = subThemeFilter.trim();
						var searchTerm = $scope.mainSearchText;

						// setting the selectedItem scope variable to selected
						// value to highlight
						if (subTheme === 'All') {
							$scope.selectedMenuItem = 'All';
						} else if (subTheme === 'Measurements') {
							$scope.selectedMenuItem = 'Measurements';
						} else if (subTheme === 'Tools and Techniques') {
							$scope.selectedMenuItem = 'Tools and Techniques';
						} else if (subTheme === 'Case Studies') {
							$scope.selectedMenuItem = 'Case Studies';
						}

						if (searchTerm != undefined && searchTerm != null
								&& searchTerm != '') {
							searchTerm = searchTerm.trim();
						} else {
							searchTerm = '*';
						}

						if (subTheme != 'All') {
							$state.go('filter-search', {
								subTheme : subTheme,
								term : searchTerm
							});
						} else {
							$state.go('home');
						}

					}

					$scope.onAboutUsClick = function() {

					}

					$scope.onSubscribeClick = function() {

					}

					var initilizeFeedbackDropdown = function() {
						$scope.feedbackDropdownOptions = [ {
							name : "I like something",
							id : 1
						}, {
							name : "I dislike something",
							id : 2
						}, {
							name : "I have a suggestion",
							id : 3
						} ];
						$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
					};

					$scope.initApp = function() {
						initilizeFeedbackDropdown();

					};

					angular
							.element(document)
							.ready(
									function() {
										console
												.log("**********IndexController*******");
										if ($rootScope.authenticated) {
											sessionStorage.setItem(
													'redirectUrl', $location
															.absUrl());
											$scope.showSessionExpired();
											$scope.initApp();
										} else {
											ControllerService
													.checkIfAlreadyAuthenticated(function() {
														$scope.selectedMenuItem = 'All';
														if ($rootScope.authenticated) {
															sessionStorage
																	.setItem(
																			'redirectUrl',
																			$location
																					.absUrl());
															$scope.initApp();
														} else {
															sessionStorage
																	.setItem(
																			'redirectUrl',
																			$location
																					.absUrl());
															$scope.initApp();
															$state.go('login');
														}
													});
										}
									});

				});