var LoginController = angularApp
		.controller(
				'LoginController',
				function LoginController($scope, $rootScope, $window, $http,
						$location, $state, UtilService, CommonDataService,
						UserDataService) {

					$scope.showBadCredentials = true;

					var clearInputFields = function() {
					}

					var authenticate = function(credentials, callback) {

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/authentication/versions/1/tickets";
					
						var body = {
						'userId' : $scope.credentials.username,
						'password' : $scope.credentials.password
						};
					
						UtilService
								.doAjax(
										method,
										url,
										body,
										function(response) {
											if (response.status === 201) {
												$rootScope.authenticated = true;
												$rootScope.displayUserName = $scope.credentials.username;
											//	console.log("response" + response);
												sessionStorage.setItem('token',
														response.data.entry.id);
												sessionStorage
														.setItem(
																'userId',
																response.data.entry.userId);
											} else {
												$rootScope.authenticated = false;
											}
											callback
													&& callback($rootScope.authenticated);
										});
					}

					$scope.onLoginClick = function() {

						console.log("Login Click");
						$scope.credentials.username = document
								.getElementById("username").value;
						$scope.credentials.password = document
								.getElementById("password").value;

						if (document.getElementById("password").value.length > 0) {

							authenticate(
									$scope.credentials,
									function() {
										if ($rootScope.authenticated) {
											console.log("authenticated");
											$rootScope.displayUserName = $scope.credentials.username;
											var redirectUrl = sessionStorage
													.getItem('redirectUrl');
											if (redirectUrl
													&& redirectUrl
															.includes("login") != true
													&& redirectUrl
															.includes("#") == true) {
												$window.location.href = redirectUrl;
											} else {
												$state.go('home');
											}
										} else {
											console.log("not authenticated");
											$state.go('login');
										}
									});
						} else {
							$rootScope.authenticated = false;
						}
					}

					angular.element(document).ready(function() {
						console.log("**********LoginController***********");
						$scope.credentials = {};
						if (sessionStorage.getItem('token')) {
							$state.go('home');
						}
					});

				});
