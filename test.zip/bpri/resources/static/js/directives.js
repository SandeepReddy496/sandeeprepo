'use strict';

/* Directives */

angular.module('angularApp.directives', []).directive('ngEnter', function() {
	return function(scope, element, attrs) {
		element.bind("keydown keypress", function(event) {
			if (event.which === 13) {
				scope.$apply(function() {
					scope.$eval(attrs.ngEnter);
				});
				event.preventDefault();
			}
		});
	};
});

angular.module('angularApp.directives', []).directive('fileModel',
		[ '$parse', function($parse) {
			return {
				restrict : 'A',
				link : function(scope, element, attrs) {
					var model = $parse(attrs.fileModel);
					var modelSetter = model.assign;

					element.bind('change', function() {
						scope.$apply(function() {
							modelSetter(scope, element[0].files[0]);
						});
					});
				}
			};
		} ]);

angular.module('angularApp.directives').directive('fileChange', function() {
	return {
		restrict : 'A',
		scope : {
			handler : '&'
		},
		link : function(scope, element) {
			element.on('change', function(event) {
				scope.$apply(function() {
					scope.handler({
						files : event.target.files
					});
				});
			});
		}
	};
});
